#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
build_unified_gui.py
Creates the upgraded, dual-scenario GUI supporting both:
  1. Institutional Library Book Collection Robot (Shriya)
  2. Grand Luxury Hotel Room Service Delivery Robot (Tanishka)
With high-fidelity visual rendering, genuine A* replanning, interactive goal selection,
telemetry tracking, difficulty scaling, and 20-seed benchmarking.
"""

content = r'''#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
library_gui.py
==============
Unified High-Fidelity Graphical User Interface (GUI) Demonstration Suite for:
  - Scenario 1: Library Book Collection Robot (Shriya - Task 3)
  - Scenario 2: Hotel Room Service Delivery Robot (Tanishka - Task 3)

SVNIT Surat — CS359: AI for Robotics
Authors: Shriya & Tanishka (SVNIT Surat)

Key Capabilities:
  - Interactive Goal Selection & Genuine Dynamic A* Replanning on Live Occupancy Grids
  - Multi-Scenario Switcher (Institutional Library <-> Grand Luxury Hotel)
  - Photorealistic Architectural Top-Down Rendering:
      * Library: Parquet floor, walnut bookshelves, study carrels, reading tables, pillars, book displays
      * Hotel: Italian marble tiles, plush royal crimson carpet runner with brass trim,
               mahogany concierge & reception desk with brass bell, executive lobby lounge,
               guest room suites (201-207) with illuminated room plaques, housekeeping storage depot
  - Real-Time Autonomous Mobile Robot (AMR) with dynamic role avatars:
      * Library AMR with scanning LiDAR & directional heading
      * Hotel Room Service AMR with domed thermal room-service cloche platter & golden handle
  - Dynamic Pedestrian Avatars:
      * Library patrons, students, and librarians
      * Hotel guests with rolling luggage suitcases and housekeeping staff pushing linen carts
  - Modular Demonstration Controls:
      * Run Full Demonstration (Automated Showcase)
      * Clean Architectural View
      * Animated A* Path Planning Exploration
      * Start / Pause / Reset Navigation
      * Interactive Goal Selection & Preset Dropdown Selection
      * 20-Seed Quantitative Benchmark Runner
  - Sim Pacing: 0.5x Demo, 1.0x Real-time, 2.0x Fast Execution
"""

from __future__ import print_function
import os
import sys
import math
import time
import argparse
import threading
import subprocess
import numpy as np
import cv2
from PIL import Image, ImageTk

# Python 2/3 compatible Tkinter import
if sys.version_info[0] >= 3:
    import tkinter as tk
    from tkinter import ttk, messagebox
    import queue
else:
    import Tkinter as tk
    import ttk
    import tkMessageBox as messagebox
    import Queue as queue

# Environment, Scenario, and Planner imports
from navrep_custom.scenarios import get_scenario_config, SCENARIO_REGISTRY
from navrep_custom.custom_envs import CustomNavRepEncodedEnv
from navrep_custom.library_book_collection import (
    sync_and_rasterize_sim,
    LibraryNavigationController,
)
from navrep_custom.hotel_room_service import HotelNavigationController
from navrep_custom.library_planner import (
    OccupancyGrid,
    AStarPlanner,
    get_library_a_star_plan,
    replan_library_route,
    validate_library_goal,
    LIBRARY_PRESET_DESTINATIONS,
    get_hotel_a_star_plan,
    replan_hotel_route,
    validate_hotel_goal,
    HOTEL_PRESET_DESTINATIONS,
)
from crowd_sim.envs.utils.info import ReachGoal, Collision, CollisionOtherAgent, Timeout


# ==============================================================================
# UI COLOR PALETTE & VISUAL CONSTANTS (Clean Dark Theme)
# ==============================================================================
THEME_BG = "#141619"
THEME_PANEL_BG = "#1d2025"
THEME_CARD_BG = "#242830"
THEME_FG = "#abb2bf"
THEME_FG_BRIGHT = "#ffffff"
THEME_ACCENT_BLUE = "#61afef"
THEME_ACCENT_GREEN = "#98c379"
THEME_ACCENT_RED = "#e06c75"
THEME_ACCENT_AMBER = "#e5c07b"
THEME_BORDER = "#3b4048"

# High-resolution architectural floor canvas colors for Library (BGR for OpenCV)
FLOOR_BASE = (212, 227, 237)      # Warm beige parquet wood floor
FLOOR_PLANK_ALT = (206, 223, 232) # Alternating plank band
FLOOR_SEAM = (191, 208, 220)      # Faint floor seam lines
BASEBOARD_COL = (27, 46, 74)      # Dark walnut perimeter trim

SHELF_BODY = (16, 33, 56)         # Deep walnut brown
SHELF_BORDER = (10, 22, 38)       # Dark walnut beveled edge
SHELF_SHADOW = (180, 195, 205)    # Soft cast shadow under shelf

TABLE_TOP = (54, 91, 141)         # Warm honey oak / walnut table surface
TABLE_BORDER = (26, 57, 96)       # Table border bevel
CHAIR_WOOD = (28, 56, 94)         # Chair curved backrest
CHAIR_CUSHION = (90, 128, 168)    # Chair fabric seat

COUNTER_BODY = (16, 36, 78)       # Mahogany counter base
COUNTER_MARBLE = (216, 229, 237)  # Polished cream marble top
COUNTER_BORDER = (10, 24, 54)     # Counter border

PILLAR_STONE = (156, 144, 120)    # Architectural concrete grey
PILLAR_BORDER = (110, 100, 80)    # Pillar beveled edge

ROBOT_BLUE = (214, 119, 2)        # Industrial cobalt blue AMR body
ROBOT_WHEEL = (30, 30, 30)        # Black rubber drive wheels
ROBOT_LIDAR = (40, 40, 40)        # Top-mounted LiDAR turret
ROBOT_HEADING = (255, 255, 255)   # White directional heading arrow
ROBOT_TRAIL = (245, 130, 32)      # Cyan visited trajectory trail

# Dynamic Human Role Colors for Library
ROLE_PATRON = (186, 104, 200)     # Browsing Patron (Violet)
ROLE_STUDENT = (154, 166, 38)     # Student (Teal)
ROLE_LIBRARIAN = (38, 117, 230)   # Librarian (Amber)
ROLE_RESEARCHER = (229, 136, 33)  # Researcher (Blue)
ROLE_STAFF = (67, 160, 71)        # Staff Member (Green)

# Hotel Scenario High-Resolution Floor Canvas Colors (BGR for OpenCV)
HOTEL_FLOOR_MARBLE = (220, 228, 236)
HOTEL_FLOOR_GROUT = (195, 205, 215)
HOTEL_CARPET_BASE = (38, 16, 115)         # Royal Burgundy plush runner
HOTEL_CARPET_PATTERN = (55, 26, 140)      # Geometric diamond pattern
HOTEL_BRASS_TRIM = (55, 195, 230)         # Golden brass border
HOTEL_WALL_WOOD = (22, 40, 75)            # Architectural walnut wood walls
HOTEL_WALL_BORDER = (12, 24, 48)
HOTEL_DOOR_MAHOGANY = (25, 48, 95)
HOTEL_DOOR_BRASS = (45, 185, 220)
HOTEL_PLAQUE_BG = (15, 30, 60)
HOTEL_PLAQUE_GOLD = (50, 215, 255)

HOTEL_RECEPTION_TOP = (24, 45, 88)
HOTEL_RECEPTION_BELL = (40, 190, 240)
HOTEL_MONITOR_BEZEL = (35, 35, 35)
HOTEL_MONITOR_SCREEN = (220, 140, 40)

HOTEL_SOFA_SAPPHIRE = (138, 52, 20)       # Sapphire velvet sofa
HOTEL_SOFA_BORDER = (90, 32, 10)
HOTEL_COFFEE_TABLE = (35, 65, 120)
HOTEL_TABLE_GLASS = (210, 215, 200)
HOTEL_PLANT_GREEN = (40, 145, 60)
HOTEL_PLANT_POT = (45, 75, 160)

HOTEL_TOWEL_WHITE = (245, 245, 245)
HOTEL_TOWEL_TEAL = (180, 170, 40)
HOTEL_HAMPER_COL = (70, 95, 125)

HOTEL_ROBOT_SILVER = (195, 200, 205)      # Brushed silver AMR
HOTEL_ROBOT_CLOCHE = (230, 235, 240)      # Silver thermal cloche dome
HOTEL_ROBOT_HANDLE = (45, 190, 235)       # Gold dome handle
HOTEL_ROBOT_AMBER = (30, 160, 240)

ROLE_GUEST = (190, 110, 35)               # Hotel Guest (Navy / Slate)
ROLE_HOUSEKEEPING = (45, 165, 95)         # Housekeeping Staff (Emerald Green)
ROLE_SUITCASE = (35, 35, 85)
ROLE_LINEN_CART = (85, 95, 105)

HOTEL_SUITE_METADATA = {
    4: ("SUITE 201", "Executive King", True),
    5: ("SUITE 202", "Deluxe Double", True),
    6: ("SUITE 203", "Presidential Suite", True),
    7: ("ROOM 205", "Superior Suite", False),
    8: ("ROOM 206", "Deluxe Twin", False),
    9: ("ROOM 207", "Junior Suite", False),
}


class LibraryDemoApp(object):
    """Main Tkinter Demonstration Application supporting Library and Hotel scenarios."""

    def __init__(self, root, default_scenario="library"):
        self.root = root
        self.active_scenario = default_scenario
        self.root.title("AUTONOMOUS MOBILE NAVIGATION — SVNIT CS359: AI for Robotics")
        self.root.geometry("1260x780")
        self.root.minsize(1180, 740)
        self.root.configure(bg=THEME_BG)

        # Simulation & Demonstration Modes
        # Mode: 'LIBRARY' (clean view), 'PLANNING' (A* animation), 'NAVIGATING' (active simulation)
        self.view_mode = "LIBRARY"
        self.is_full_demo_active = False

        self.current_difficulty = "EASY"
        self.pacing_speed = 0.5  # 0.5x default
        self.step_delay_ms = int(200 / self.pacing_speed)  # 400ms at 0.5x

        self.is_running = False
        self.is_paused = False
        self.is_benchmark_running = False
        self.current_seed = 42

        # Env, Controller, and Planner
        self.env = None
        self.cfg = None
        self.ctrl = None
        self.planner_data = None
        self.active_a_star_waypoints = None

        # A* Animation State
        self.planning_keyframe_idx = 0
        self.is_planning_animating = False

        # Live Episode Variables
        self.current_step = 0
        self.max_steps = 380
        self.trajectory = []
        self.terminal_event = None
        self.nav_state_str = "READY"

        # Interactive Goal Selection & Dynamic Replanning State
        self.is_selecting_goal = False
        self.selected_goal = None              # [gx, gy] (metric coordinates)
        self.selected_goal_label = None        # Name of destination
        self.mouse_hover_coords = None         # (wx, wy)
        self.original_goal = [5.5, -3.5] if self.active_scenario == "library" else [10.0, 0.0]

        # Background benchmark queue
        self.benchmark_queue = queue.Queue()

        # Canvas Dimensions & Metric Transformation
        self.canvas_width = 860
        self.canvas_height = 640
        self._update_scenario_geometry(init=True)

        # Precompute A* plan
        self._compute_a_star_plan()

        # Build UI layout
        self._setup_styles()
        self._build_header()
        self._build_main_body()

        # Initialize simulation and render initial frame
        self.reset_simulation()
        self._render_current_frame()

        # Check queue loop
        self.root.after(100, self._process_benchmark_queue)

    # --------------------------------------------------------------------------
    # SCENARIO GEOMETRY & SWITCHING
    # --------------------------------------------------------------------------
    def _update_scenario_geometry(self, init=False):
        if self.active_scenario == "hotelroomservice":
            self.world_min_x = -12.5
            self.world_max_x = 12.5
            self.world_min_y = -8.5
            self.world_max_y = 8.5
            self.original_goal = [10.0, 0.0]
            if not init:
                self.lbl_title.configure(text="HOTEL ROOM SERVICE DELIVERY ROBOT")
                self.lbl_sub.configure(text="Task 3: Autonomous Room Service Delivery in Grand Hotel | Authors: Tanishka & Shriya (SVNIT)")
                self.lbl_canvas_title.configure(text="GRAND LUXURY HOTEL FLOOR PLAN (860x640) -- CORRIDOR, LOUNGE & GUEST SUITES")
                self._rebuild_preset_menu(HOTEL_PRESET_DESTINATIONS)
        else:
            self.world_min_x = -10.5
            self.world_max_x = 7.5
            self.world_min_y = -5.5
            self.world_max_y = 5.5
            self.original_goal = [5.5, -3.5]
            if not init:
                self.lbl_title.configure(text="LIBRARY BOOK COLLECTION ROBOT")
                self.lbl_sub.configure(text="Task 3: Autonomous Mobile Navigation in Institutional Library | Author: Shriya (SVNIT Surat)")
                self.lbl_canvas_title.configure(text="INSTITUTIONAL LIBRARY FLOOR PLAN (860x640) -- WEST/EAST WINGS & READING HALL")
                self._rebuild_preset_menu(LIBRARY_PRESET_DESTINATIONS)

        self.scale_px = min(
            (self.canvas_width - 40) / (self.world_max_x - self.world_min_x),
            (self.canvas_height - 40) / (self.world_max_y - self.world_min_y)
        )
        self.orig_x = int(20 + (-self.world_min_x) * self.scale_px)
        self.orig_y = int(self.canvas_height / 2.0)

    def switch_scenario(self, scenario_name):
        """Switches between Library Book Collection and Hotel Room Service scenarios."""
        if self.active_scenario == scenario_name and self.env is not None:
            return
        self.active_scenario = scenario_name
        if self.is_running:
            self.on_pause_pressed()
        self.is_full_demo_active = False
        self.view_mode = "LIBRARY"
        self.selected_goal = None
        self.selected_goal_label = None
        self.is_selecting_goal = False

        if hasattr(self, 'btn_sc_lib') and hasattr(self, 'btn_sc_hotel'):
            self.btn_sc_lib.configure(bg="#0277bd" if self.active_scenario == "library" else "#37474f")
            self.btn_sc_hotel.configure(bg="#ad1457" if self.active_scenario == "hotelroomservice" else "#37474f")

        self._update_scenario_geometry()
        self._compute_a_star_plan()
        self.reset_simulation()
        self._render_current_frame()

    def _rebuild_preset_menu(self, preset_list):
        if not hasattr(self, 'opt_preset'):
            return
        menu = self.opt_preset["menu"]
        menu.delete(0, "end")
        for name, _ in preset_list:
            menu.add_command(label=name, command=lambda val=name: self._handle_preset_selection(val))
        if preset_list:
            self.preset_var.set(preset_list[0][0])

    # --------------------------------------------------------------------------
    # A* PLAN INITIALIZATION
    # --------------------------------------------------------------------------
    def _compute_a_star_plan(self):
        """Computes or retrieves cached A* plan from active scenario static obstacles."""
        try:
            if self.active_scenario == "hotelroomservice":
                self.planner_data = get_hotel_a_star_plan()
                self.active_a_star_waypoints = [list(wp) for wp in self.planner_data['waypoints']]
                self.ctrl = HotelNavigationController(waypoints=self.active_a_star_waypoints)
            else:
                self.planner_data = get_library_a_star_plan()
                self.active_a_star_waypoints = [list(wp) for wp in self.planner_data['waypoints']]
                self.ctrl = LibraryNavigationController(waypoints=self.active_a_star_waypoints)
        except Exception as e:
            print("[WARN] A* plan computation exception:", e)
            self.planner_data = None
            self.active_a_star_waypoints = None
            if self.active_scenario == "hotelroomservice":
                self.ctrl = HotelNavigationController()
            else:
                self.ctrl = LibraryNavigationController()

    # --------------------------------------------------------------------------
    # UI SETUP & STYLING
    # --------------------------------------------------------------------------
    def _setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TFrame", background=THEME_PANEL_BG)
        style.configure("TLabel", background=THEME_PANEL_BG, foreground=THEME_FG, font=("Helvetica", 10))

    def _build_header(self):
        header = tk.Frame(self.root, bg=THEME_CARD_BG, height=60, bd=1, relief="ridge")
        header.pack(fill="x", side="top", padx=8, pady=(8, 4))

        title_frame = tk.Frame(header, bg=THEME_CARD_BG)
        title_frame.pack(side="left", padx=16, pady=6)

        title_text = "LIBRARY BOOK COLLECTION ROBOT" if self.active_scenario == "library" else "HOTEL ROOM SERVICE DELIVERY ROBOT"
        self.lbl_title = tk.Label(
            title_frame,
            text=title_text,
            font=("Helvetica", 14, "bold"),
            fg=THEME_FG_BRIGHT,
            bg=THEME_CARD_BG
        )
        self.lbl_title.pack(anchor="w")

        sub_text = "Task 3: Autonomous Mobile Navigation in Institutional Library | Author: Shriya (SVNIT Surat)" if self.active_scenario == "library" else "Task 3: Autonomous Room Service Delivery in Grand Hotel | Authors: Tanishka & Shriya (SVNIT)"
        self.lbl_sub = tk.Label(
            title_frame,
            text=sub_text,
            font=("Helvetica", 9),
            fg=THEME_ACCENT_BLUE,
            bg=THEME_CARD_BG
        )
        self.lbl_sub.pack(anchor="w")

        # Badges on right side
        badge_frame = tk.Frame(header, bg=THEME_CARD_BG)
        badge_frame.pack(side="right", padx=16, pady=6)

        self.lbl_header_mode = tk.Label(
            badge_frame,
            text="MODE: MAP VIEW",
            font=("Helvetica", 9, "bold"),
            fg="#21252b",
            bg="#80deea",
            padx=8,
            pady=3,
            relief="groove"
        )
        self.lbl_header_mode.pack(side="left", padx=3)

        self.lbl_header_diff = tk.Label(
            badge_frame,
            text="DIFFICULTY: EASY",
            font=("Helvetica", 9, "bold"),
            fg="#21252b",
            bg=THEME_ACCENT_GREEN,
            padx=8,
            pady=3,
            relief="groove"
        )
        self.lbl_header_diff.pack(side="left", padx=3)

        self.lbl_header_status = tk.Label(
            badge_frame,
            text="STATUS: READY",
            font=("Helvetica", 9, "bold"),
            fg="#21252b",
            bg="#9e9e9e",
            padx=10,
            pady=3,
            relief="groove"
        )
        self.lbl_header_status.pack(side="left", padx=3)

    def _build_main_body(self):
        body = tk.Frame(self.root, bg=THEME_BG)
        body.pack(fill="both", expand=True, padx=8, pady=4)

        # LEFT: Large Map Canvas (70% width)
        left_frame = tk.Frame(body, bg=THEME_PANEL_BG, bd=1, relief="ridge")
        left_frame.pack(side="left", fill="both", expand=True, padx=(0, 6))

        canvas_header = tk.Frame(left_frame, bg=THEME_CARD_BG, height=28)
        canvas_header.pack(fill="x", side="top", padx=2, pady=2)
        initial_c_title = "INSTITUTIONAL LIBRARY FLOOR PLAN (860x640) -- WEST/EAST WINGS & READING HALL" if self.active_scenario == "library" else "GRAND LUXURY HOTEL FLOOR PLAN (860x640) -- CORRIDOR, LOUNGE & GUEST SUITES"
        self.lbl_canvas_title = tk.Label(
            canvas_header,
            text=initial_c_title,
            font=("Helvetica", 9, "bold"),
            fg=THEME_FG,
            bg=THEME_CARD_BG
        )
        self.lbl_canvas_title.pack(side="left", padx=8, pady=4)

        self.canvas = tk.Canvas(
            left_frame,
            width=self.canvas_width,
            height=self.canvas_height,
            bg="#111216",
            highlightthickness=0
        )
        self.canvas.pack(fill="both", expand=True, padx=4, pady=4)
        self.canvas.bind("<Button-1>", self.on_canvas_clicked)
        self.canvas.bind("<Motion>", self.on_canvas_motion)

        # RIGHT: Side Control & Telemetry Panel (30% width)
        right_panel = tk.Frame(body, bg=THEME_PANEL_BG, width=370, bd=1, relief="ridge")
        right_panel.pack(side="right", fill="y", padx=(2, 0))
        right_panel.pack_propagate(False)

        # 0. Scenario Selection Card
        sc_card = tk.LabelFrame(
            right_panel,
            text=" Active Robot Scenario ",
            font=("Helvetica", 9, "bold"),
            fg=THEME_ACCENT_AMBER,
            bg=THEME_CARD_BG,
            bd=1,
            relief="groove"
        )
        sc_card.pack(fill="x", padx=8, pady=(4, 2))

        self.btn_sc_lib = tk.Button(
            sc_card,
            text="[1] Institutional Library Book Collection",
            font=("Helvetica", 8, "bold"),
            bg="#0277bd" if self.active_scenario == "library" else "#37474f",
            fg="white",
            relief="groove",
            bd=2,
            command=lambda: self.switch_scenario("library")
        )
        self.btn_sc_lib.pack(fill="x", padx=6, pady=2)

        self.btn_sc_hotel = tk.Button(
            sc_card,
            text="[2] Grand Hotel Room Service Delivery",
            font=("Helvetica", 8, "bold"),
            bg="#ad1457" if self.active_scenario == "hotelroomservice" else "#37474f",
            fg="white",
            relief="groove",
            bd=2,
            command=lambda: self.switch_scenario("hotelroomservice")
        )
        self.btn_sc_hotel.pack(fill="x", padx=6, pady=(0, 3))

        # 1. PRIMARY: Full Demonstration Showcase
        demo_card = tk.LabelFrame(
            right_panel,
            text=" Showcase Demonstration ",
            font=("Helvetica", 10, "bold"),
            fg=THEME_ACCENT_GREEN,
            bg=THEME_CARD_BG,
            bd=2,
            relief="groove"
        )
        demo_card.pack(fill="x", padx=8, pady=(6, 4))

        self.btn_full_demo = tk.Button(
            demo_card,
            text="[>] RUN FULL DEMONSTRATION",
            font=("Helvetica", 10, "bold"),
            bg="#2e7d32",
            fg="white",
            activebackground="#388e3c",
            activeforeground="white",
            height=2,
            command=self.on_run_full_demonstration_pressed
        )
        self.btn_full_demo.pack(fill="x", padx=6, pady=4)

        lbl_demo_hint = tk.Label(
            demo_card,
            text="Automated sequence: View Map -> A* Search -> Navigate & Yield -> Dock",
            font=("Helvetica", 8),
            fg=THEME_FG,
            bg=THEME_CARD_BG
        )
        lbl_demo_hint.pack(anchor="w", padx=8, pady=(0, 4))

        # 2. Modular Controls
        ctrl_card = tk.LabelFrame(
            right_panel,
            text=" Modular Operations ",
            font=("Helvetica", 9, "bold"),
            fg=THEME_ACCENT_BLUE,
            bg=THEME_CARD_BG,
            bd=1,
            relief="groove"
        )
        ctrl_card.pack(fill="x", padx=8, pady=4)

        row1 = tk.Frame(ctrl_card, bg=THEME_CARD_BG)
        row1.pack(fill="x", padx=4, pady=2)

        self.btn_show_lib = tk.Button(
            row1,
            text="Show Environment",
            font=("Helvetica", 8, "bold"),
            bg="#37474f",
            fg="white",
            command=self.on_show_library_pressed
        )
        self.btn_show_lib.pack(side="left", expand=True, fill="x", padx=2)

        self.btn_plan = tk.Button(
            row1,
            text="Run Path Planning",
            font=("Helvetica", 8, "bold"),
            bg="#0277bd",
            fg="white",
            activebackground="#0288d1",
            command=self.on_run_path_planning_pressed
        )
        self.btn_plan.pack(side="left", expand=True, fill="x", padx=2)

        row2 = tk.Frame(ctrl_card, bg=THEME_CARD_BG)
        row2.pack(fill="x", padx=4, pady=2)

        self.btn_start = tk.Button(
            row2,
            text="Start Navigation",
            font=("Helvetica", 8, "bold"),
            bg="#2e7d32",
            fg="white",
            command=self.on_start_pressed
        )
        self.btn_start.pack(side="left", expand=True, fill="x", padx=2)

        self.btn_pause = tk.Button(
            row2,
            text="Pause",
            font=("Helvetica", 8, "bold"),
            bg="#f57c00",
            fg="white",
            state="disabled",
            command=self.on_pause_pressed
        )
        self.btn_pause.pack(side="left", expand=True, fill="x", padx=2)

        self.btn_reset = tk.Button(
            row2,
            text="Reset",
            font=("Helvetica", 8, "bold"),
            bg="#455a64",
            fg="white",
            command=self.on_reset_pressed
        )
        self.btn_reset.pack(side="left", expand=True, fill="x", padx=2)

        # 3. Interactive Goal Selection & Dynamic Replanning
        goal_card = tk.LabelFrame(
            right_panel,
            text=" Interactive Goal Selection & Replanning ",
            font=("Helvetica", 9, "bold"),
            fg=THEME_ACCENT_AMBER,
            bg=THEME_CARD_BG,
            bd=1,
            relief="groove"
        )
        goal_card.pack(fill="x", padx=8, pady=4)

        row_g1 = tk.Frame(goal_card, bg=THEME_CARD_BG)
        row_g1.pack(fill="x", padx=4, pady=2)

        self.btn_select_goal = tk.Button(
            row_g1,
            text="[+] SELECT NEW GOAL",
            font=("Helvetica", 8, "bold"),
            bg="#00838f",
            fg="white",
            activebackground="#0097a7",
            activeforeground="white",
            command=self.on_select_new_goal_pressed
        )
        self.btn_select_goal.pack(side="left", expand=True, fill="x", padx=2)

        self.btn_replan = tk.Button(
            row_g1,
            text="REPLAN ROUTE",
            font=("Helvetica", 8, "bold"),
            bg="#e65100",
            fg="white",
            activebackground="#f57c00",
            activeforeground="white",
            command=self.on_replan_pressed
        )
        self.btn_replan.pack(side="left", expand=True, fill="x", padx=2)

        row_g2 = tk.Frame(goal_card, bg=THEME_CARD_BG)
        row_g2.pack(fill="x", padx=4, pady=2)

        lbl_preset = tk.Label(row_g2, text="Preset:", font=("Helvetica", 8, "bold"), fg=THEME_FG, bg=THEME_CARD_BG)
        lbl_preset.pack(side="left", padx=(2, 2))

        preset_options = [name for name, _ in (HOTEL_PRESET_DESTINATIONS if self.active_scenario == "hotelroomservice" else LIBRARY_PRESET_DESTINATIONS)]
        self.preset_var = tk.StringVar(value=preset_options[0])
        self.opt_preset = tk.OptionMenu(
            row_g2,
            self.preset_var,
            *preset_options,
            command=self.on_preset_destination_selected
        )
        self.opt_preset.config(font=("Helvetica", 7, "bold"), bg=THEME_PANEL_BG, fg=THEME_FG_BRIGHT, activebackground="#37474f", highlightthickness=0, bd=1, relief="groove", width=20, anchor="w")
        self.opt_preset.pack(side="left", fill="x", expand=True, padx=2)

        self.btn_reset_scenario = tk.Button(
            row_g2,
            text="Reset Original",
            font=("Helvetica", 7, "bold"),
            bg="#37474f",
            fg="white",
            command=self.on_reset_to_original_pressed
        )
        self.btn_reset_scenario.pack(side="left", padx=2)

        self.lbl_goal_status = tk.Label(
            goal_card,
            text="Click 'SELECT NEW GOAL' or choose a preset destination.",
            font=("Helvetica", 8),
            fg=THEME_ACCENT_BLUE,
            bg=THEME_CARD_BG,
            wraplength=340,
            justify="left"
        )
        self.lbl_goal_status.pack(anchor="w", padx=6, pady=(1, 3))

        # 4. Difficulty & Speed Configuration
        cfg_frame = tk.Frame(right_panel, bg=THEME_PANEL_BG)
        cfg_frame.pack(fill="x", padx=8, pady=4)

        diff_card = tk.LabelFrame(cfg_frame, text=" Difficulty ", font=("Helvetica", 8, "bold"), fg=THEME_ACCENT_BLUE, bg=THEME_CARD_BG)
        diff_card.pack(side="left", fill="both", expand=True, padx=(0, 2))

        self.diff_var = tk.StringVar(value=self.current_difficulty)
        for diff in ["EASY", "MEDIUM", "HARD"]:
            rb = tk.Radiobutton(
                diff_card,
                text=diff,
                value=diff,
                variable=self.diff_var,
                font=("Helvetica", 8, "bold"),
                fg=THEME_FG_BRIGHT,
                bg=THEME_CARD_BG,
                selectcolor=THEME_PANEL_BG,
                activebackground=THEME_CARD_BG,
                command=self.on_difficulty_changed
            )
            rb.pack(anchor="w", padx=4, pady=1)

        speed_card = tk.LabelFrame(cfg_frame, text=" Sim Pacing ", font=("Helvetica", 8, "bold"), fg=THEME_ACCENT_BLUE, bg=THEME_CARD_BG)
        speed_card.pack(side="right", fill="both", expand=True, padx=(2, 0))

        self.speed_var = tk.DoubleVar(value=self.pacing_speed)
        for speed, label in [(0.5, "0.5x (Demo)"), (1.0, "1.0x (Real)"), (2.0, "2.0x (Fast)")]:
            rb = tk.Radiobutton(
                speed_card,
                text=label,
                value=speed,
                variable=self.speed_var,
                font=("Helvetica", 8),
                fg=THEME_FG_BRIGHT,
                bg=THEME_CARD_BG,
                selectcolor=THEME_PANEL_BG,
                activebackground=THEME_CARD_BG,
                command=self.on_pacing_speed_changed
            )
            rb.pack(anchor="w", padx=4, pady=1)

        # 5. Live Telemetry & Navigation State
        telem_card = tk.LabelFrame(
            right_panel,
            text=" Live Telemetry & Navigation State ",
            font=("Helvetica", 8, "bold"),
            fg=THEME_ACCENT_BLUE,
            bg=THEME_CARD_BG
        )
        telem_card.pack(fill="x", padx=8, pady=4)

        self.lbl_telem_step = tk.Label(telem_card, text="Step:   0 / 380 | Sim Time:  0.0s / 76.0s", font=("Courier", 8), fg=THEME_FG_BRIGHT, bg=THEME_CARD_BG)
        self.lbl_telem_step.pack(anchor="w", padx=6, pady=1)

        self.lbl_telem_pos = tk.Label(telem_card, text="Pose: (-8.00m, +3.50m) | th = +0.0 deg", font=("Courier", 8), fg=THEME_FG_BRIGHT, bg=THEME_CARD_BG)
        self.lbl_telem_pos.pack(anchor="w", padx=6, pady=1)

        self.lbl_telem_vel = tk.Label(telem_card, text="Speed: |v|=0.00 m/s (vx=+0.00, vy=+0.00)", font=("Courier", 8), fg=THEME_FG_BRIGHT, bg=THEME_CARD_BG)
        self.lbl_telem_vel.pack(anchor="w", padx=6, pady=1)

        self.lbl_telem_goal = tk.Label(telem_card, text="Dist to Goal: 15.20 m (+5.5, -3.5)", font=("Courier", 8), fg=THEME_ACCENT_AMBER, bg=THEME_CARD_BG)
        self.lbl_telem_goal.pack(anchor="w", padx=6, pady=1)

        self.lbl_telem_wp = tk.Label(telem_card, text="Active Waypoint: WP 0 (Start)", font=("Courier", 8), fg=THEME_FG_BRIGHT, bg=THEME_CARD_BG)
        self.lbl_telem_wp.pack(anchor="w", padx=6, pady=1)

        self.lbl_telem_state = tk.Label(telem_card, text="Controller State: READY", font=("Courier", 8, "bold"), fg=THEME_ACCENT_GREEN, bg=THEME_CARD_BG)
        self.lbl_telem_state.pack(anchor="w", padx=6, pady=1)

        # 6. A* Search Metrics Card
        plan_card = tk.LabelFrame(
            right_panel,
            text=" A* Search Metrics & Plan Details ",
            font=("Helvetica", 8, "bold"),
            fg=THEME_ACCENT_BLUE,
            bg=THEME_CARD_BG
        )
        plan_card.pack(fill="x", padx=8, pady=4)

        self.lbl_plan_status = tk.Label(plan_card, text="Algorithm: Genuine A* Grid Search [f(n)=g(n)+h(n)]", font=("Helvetica", 7), fg=THEME_FG, bg=THEME_CARD_BG)
        self.lbl_plan_status.pack(anchor="w", padx=6, pady=1)

        self.lbl_plan_stats1 = tk.Label(plan_card, text="Explored: 0 cells | Length: 17.31 m", font=("Courier", 8), fg=THEME_FG_BRIGHT, bg=THEME_CARD_BG)
        self.lbl_plan_stats1.pack(anchor="w", padx=6, pady=1)

        self.lbl_plan_stats2 = tk.Label(plan_card, text="Time: 0.0 ms | Res: 0.10m | Waypoints: 7", font=("Courier", 8), fg=THEME_FG_BRIGHT, bg=THEME_CARD_BG)
        self.lbl_plan_stats2.pack(anchor="w", padx=6, pady=1)

        # 7. Quantitative Benchmark Card
        bench_card = tk.LabelFrame(
            right_panel,
            text=" 20-Seed Quantitative Benchmark ",
            font=("Helvetica", 8, "bold"),
            fg=THEME_ACCENT_BLUE,
            bg=THEME_CARD_BG
        )
        bench_card.pack(fill="x", padx=8, pady=4)

        self.btn_benchmark = tk.Button(
            bench_card,
            text="Run 20-Seed Benchmark",
            font=("Helvetica", 8, "bold"),
            bg="#1565c0",
            fg="white",
            command=self.on_run_benchmark_pressed
        )
        self.btn_benchmark.pack(fill="x", padx=6, pady=2)

        self.lbl_bench_progress = tk.Label(bench_card, text="Ready (Evaluates Seeds 42-61 across 3 tiers)", font=("Helvetica", 7), fg=THEME_FG, bg=THEME_CARD_BG)
        self.lbl_bench_progress.pack(anchor="w", padx=6, pady=1)

        table_frame = tk.Frame(bench_card, bg="#1e2227", bd=1, relief="sunken")
        table_frame.pack(fill="x", padx=4, pady=2)

        tk.Label(table_frame, text="Diff | Success | Collision | Timeout | Avg Time", font=("Courier", 7, "bold"), fg=THEME_ACCENT_AMBER, bg="#1e2227").pack(anchor="w", padx=4, pady=1)
        self.lbl_bench_easy = tk.Label(table_frame, text="EASY   : 100.0% (20/20) | 0% |  0% | 23.4s", font=("Courier", 7), fg="#98c379", bg="#1e2227")
        self.lbl_bench_easy.pack(anchor="w", padx=4)
        self.lbl_bench_med = tk.Label(table_frame, text="MEDIUM : 100.0% (20/20) | 0% |  0% | 26.2s", font=("Courier", 7), fg="#98c379", bg="#1e2227")
        self.lbl_bench_med.pack(anchor="w", padx=4)
        self.lbl_bench_hard = tk.Label(table_frame, text="HARD   : 100.0% (20/20) | 0% |  0% | 28.5s", font=("Courier", 7), fg="#98c379", bg="#1e2227")
        self.lbl_bench_hard.pack(anchor="w", padx=4, pady=(0, 2))

    # --------------------------------------------------------------------------
    # SIMULATION INITIALIZATION & MODES
    # --------------------------------------------------------------------------
    def reset_simulation(self):
        """Initializes or resets the simulation environment."""
        self.is_running = False
        self.is_paused = False
        self.is_planning_animating = False
        self.is_selecting_goal = False
        if hasattr(self, 'btn_select_goal'):
            self.btn_select_goal.configure(text="[+] SELECT NEW GOAL", bg="#00838f")
            self.canvas.config(cursor="")

        self.btn_start.configure(text="Start Navigation", state="normal")
        self.btn_pause.configure(text="Pause", state="disabled")

        if self.env is not None:
            try:
                self.env.close()
            except Exception:
                pass

        np.random.seed(self.current_seed)
        self.cfg = get_scenario_config(self.active_scenario)
        self.env = CustomNavRepEncodedEnv(
            scenario=self.active_scenario,
            difficulty=self.current_difficulty,
            gpu=False,
            silent=True
        )
        self.env.reset(self.active_scenario, self.current_difficulty)
        sync_and_rasterize_sim(self.env.raw_env, self.cfg)

        if self.selected_goal is not None:
            self.env.soadrl_sim.robot.gx = self.selected_goal[0]
            self.env.soadrl_sim.robot.gy = self.selected_goal[1]

        # Initialize controller with calculated A* waypoints
        if self.active_scenario == "hotelroomservice":
            if self.active_a_star_waypoints is not None:
                self.ctrl = HotelNavigationController(waypoints=self.active_a_star_waypoints)
            else:
                self.ctrl = HotelNavigationController()
        else:
            if self.active_a_star_waypoints is not None:
                self.ctrl = LibraryNavigationController(waypoints=self.active_a_star_waypoints)
            else:
                self.ctrl = LibraryNavigationController()
        self.ctrl.reset()

        self.current_step = 0
        self.trajectory = [list(self.cfg.robot_start[:2])]
        self.terminal_event = None
        self.nav_state_str = "CRUISING (Service Corridor)" if self.active_scenario == "hotelroomservice" else "CRUISING (Stack Aisle 2)"

        self._update_badges("READY", "#9e9e9e")
        self._update_telemetry(0.0, 0.0)
        self._render_current_frame()

    def on_show_library_pressed(self):
        """Resets view mode to clean environment view."""
        self.view_mode = "LIBRARY"
        self.is_full_demo_active = False
        self.lbl_header_mode.configure(text="MODE: MAP VIEW", bg="#80deea")
        if self.active_scenario == "hotelroomservice":
            self.lbl_canvas_title.configure(text="GRAND LUXURY HOTEL FLOOR PLAN (860x640) -- CORRIDOR, LOUNGE & GUEST SUITES")
        else:
            self.lbl_canvas_title.configure(text="INSTITUTIONAL LIBRARY FLOOR PLAN (860x640) -- WEST/EAST WINGS & READING HALL")
        self._render_current_frame()

    def on_run_path_planning_pressed(self):
        """Starts the animated A* search visualization."""
        if self.is_running:
            self.on_pause_pressed()

        self.view_mode = "PLANNING"
        self.is_planning_animating = True
        self.planning_keyframe_idx = 0
        self.lbl_header_mode.configure(text="MODE: A* PATH PLANNING", bg="#ffb74d")
        self.lbl_canvas_title.configure(text="A* OCCUPANCY GRID SEARCH ANIMATION -- f(n) = g(n) + h(n)")
        self._animate_planning_step()

    def _animate_planning_step(self):
        """Animates A* search frontier expanding."""
        if not self.is_planning_animating or self.planner_data is None:
            return

        keyframes = self.planner_data.get('animation_keyframes', [])
        if self.planning_keyframe_idx < len(keyframes):
            self.planning_keyframe_idx += 1
            self._render_current_frame()
            self.root.after(35, self._animate_planning_step)
        else:
            self.is_planning_animating = False
            self.lbl_header_mode.configure(text="MODE: A* PLAN COMPLETE", bg="#98c379")
            self._render_current_frame()

            if self.is_full_demo_active:
                self.root.after(1200, self._continue_full_demo_to_navigation)

    def on_run_full_demonstration_pressed(self):
        """Executes full automated 3-stage showcase demonstration."""
        self.is_full_demo_active = True
        self.reset_simulation()
        self.on_run_path_planning_pressed()

    def _continue_full_demo_to_navigation(self):
        if not self.is_full_demo_active:
            return
        self.on_start_pressed()

    def on_start_pressed(self):
        """Starts or resumes simulation."""
        if self.is_planning_animating:
            self.is_planning_animating = False

        self.view_mode = "NAVIGATING"
        self.is_running = True
        self.is_paused = False
        self.btn_start.configure(text="Running...", state="disabled")
        self.btn_pause.configure(text="Pause", state="normal")
        self.lbl_header_mode.configure(text="MODE: AUTONOMOUS NAVIGATION", bg="#98c379")
        if self.active_scenario == "hotelroomservice":
            self.lbl_canvas_title.configure(text="AUTONOMOUS ROOM SERVICE DELIVERY ALONG A* CORRIDOR ROUTE")
        else:
            self.lbl_canvas_title.configure(text="AUTONOMOUS NAVIGATION ALONG A* CALCULATED CORRIDOR ROUTE")
        self._update_badges("NAVIGATING", "#2e7d32")
        self._step_simulation_loop()

    def on_pause_pressed(self):
        """Toggles pause/resume state."""
        if not self.is_running:
            return

        self.is_paused = not self.is_paused
        if self.is_paused:
            self.btn_pause.configure(text="Resume", bg="#2e7d32")
            self._update_badges("PAUSED", "#f57c00")
            self.lbl_goal_status.configure(text="Simulation paused. Click 'Resume' or select a new goal.", fg=THEME_ACCENT_AMBER)
        else:
            self.btn_pause.configure(text="Pause", bg="#f57c00")
            self._update_badges("NAVIGATING", "#2e7d32")
            self._step_simulation_loop()

    def on_reset_pressed(self):
        """Resets the episode to start pose."""
        self.is_full_demo_active = False
        self.view_mode = "LIBRARY"
        self.reset_simulation()
        self.lbl_header_mode.configure(text="MODE: MAP VIEW", bg="#80deea")
        if self.active_scenario == "hotelroomservice":
            self.lbl_canvas_title.configure(text="GRAND LUXURY HOTEL FLOOR PLAN (860x640) -- CORRIDOR, LOUNGE & GUEST SUITES")
        else:
            self.lbl_canvas_title.configure(text="INSTITUTIONAL LIBRARY FLOOR PLAN (860x640) -- WEST/EAST WINGS & READING HALL")

    def on_difficulty_changed(self):
        """Handles switching between EASY, MEDIUM, and HARD crowd tiers."""
        self.current_difficulty = self.diff_var.get()
        diff_colors = {
            "EASY": THEME_ACCENT_GREEN,
            "MEDIUM": "#ffb74d",
            "HARD": THEME_ACCENT_RED
        }
        self.lbl_header_diff.configure(
            text="DIFFICULTY: {}".format(self.current_difficulty),
            bg=diff_colors.get(self.current_difficulty, THEME_ACCENT_GREEN)
        )
        self.reset_simulation()

    def on_pacing_speed_changed(self):
        """Adjusts the simulation pacing delay."""
        self.pacing_speed = self.speed_var.get()
        self.step_delay_ms = max(20, int(200 / self.pacing_speed))

    # --------------------------------------------------------------------------
    # INTERACTIVE GOAL SELECTION & DYNAMIC REPLANNING
    # --------------------------------------------------------------------------
    def on_select_new_goal_pressed(self):
        """Activates interactive goal selection mode."""
        self.is_selecting_goal = not self.is_selecting_goal
        if self.is_selecting_goal:
            self.btn_select_goal.configure(text="[x] CANCEL SELECTION", bg="#c62828")
            self.lbl_goal_status.configure(
                text="Click a reachable location on the map to set a new destination.",
                fg=THEME_ACCENT_AMBER
            )
            self.canvas.config(cursor="crosshair")
        else:
            self.btn_select_goal.configure(text="[+] SELECT NEW GOAL", bg="#00838f")
            self.lbl_goal_status.configure(
                text="Goal selection cancelled.",
                fg=THEME_FG
            )
            self.canvas.config(cursor="")
        self._render_current_frame()

    def on_canvas_motion(self, event):
        """Tracks cursor over canvas and shows metric coordinates."""
        if self.is_selecting_goal:
            wx, wy = self._px2w(event.x, event.y)
            self.mouse_hover_coords = (wx, wy)
            if self.is_selecting_goal:
                self.lbl_goal_status.configure(
                    text="Pointer: ({:+.2f}m, {:+.2f}m) -- Click to choose destination".format(wx, wy),
                    fg=THEME_ACCENT_AMBER
                )

    def on_canvas_clicked(self, event):
        """Handles map clicks for dynamic goal selection."""
        if not self.is_selecting_goal:
            return

        wx, wy = self._px2w(event.x, event.y)
        wx, wy = round(wx, 2), round(wy, 2)
        if self.active_scenario == "hotelroomservice":
            valid, reason = validate_hotel_goal((wx, wy))
        else:
            valid, reason = validate_library_goal((wx, wy))

        if not valid:
            self.lbl_goal_status.configure(
                text="[!] Invalid Goal: {}".format(reason),
                fg=THEME_ACCENT_RED
            )
            self._update_badges("INVALID GOAL", "#e06c75")
            return

        # Valid location selected
        self.is_selecting_goal = False
        self.btn_select_goal.configure(text="[+] SELECT NEW GOAL", bg="#00838f")
        self.canvas.config(cursor="")
        label = "Custom Target ({:+.2f}, {:+.2f})".format(wx, wy)
        self._apply_new_destination([wx, wy], label)

    def on_preset_destination_selected(self, selection):
        """Handles selection of a destination preset from dropdown."""
        self._handle_preset_selection(selection)

    def _handle_preset_selection(self, selection):
        self.preset_var.set(selection)
        presets = HOTEL_PRESET_DESTINATIONS if self.active_scenario == "hotelroomservice" else LIBRARY_PRESET_DESTINATIONS
        coords = None
        for name, pt in presets:
            if name == selection:
                coords = pt
                break
        if coords is None:
            return

        if self.active_scenario == "hotelroomservice":
            valid, reason = validate_hotel_goal(coords)
        else:
            valid, reason = validate_library_goal(coords)

        if not valid:
            self.lbl_goal_status.configure(
                text="[!] Preset Invalid: {}".format(reason),
                fg=THEME_ACCENT_RED
            )
            return

        self._apply_new_destination(list(coords), selection)

    def _apply_new_destination(self, coords, label):
        """Sets destination and triggers genuine dynamic A* replanning."""
        self.selected_goal = list(coords)
        self.selected_goal_label = label

        # Pause robot if moving
        if self.is_running and not self.is_paused:
            self.on_pause_pressed()

        self.lbl_goal_status.configure(
            text="Destination: {} | ({:+.2f}, {:+.2f})".format(label, coords[0], coords[1]),
            fg=THEME_ACCENT_GREEN
        )
        # Execute genuine dynamic replanning
        self.on_replan_pressed()

    def on_replan_pressed(self):
        """
        Executes genuine dynamic A* replanning from robot's CURRENT position to selected goal.
        """
        if self.selected_goal is None:
            self.lbl_goal_status.configure(
                text="[!] Please select a new destination on map or preset first.",
                fg=THEME_ACCENT_AMBER
            )
            return

        if self.is_running and not self.is_paused:
            self.on_pause_pressed()

        # Current robot pose in metric coordinates
        robot = self.env.soadrl_sim.robot
        start_xy = [robot.px, robot.py]
        goal_xy = self.selected_goal

        # Stage A: New goal selected
        self.view_mode = "PLANNING"
        self.lbl_header_mode.configure(text="MODE: DYNAMIC A* REPLANNING", bg="#ff9800")
        self.lbl_canvas_title.configure(
            text="CALCULATING NEW ROUTE FROM ({:+.2f}, {:+.2f}) TO ({:+.2f}, {:+.2f})".format(
                start_xy[0], start_xy[1], goal_xy[0], goal_xy[1]
            )
        )
        self._update_badges("REPLANNING", "#ff9800")
        self.lbl_goal_status.configure(text="Calculating optimal collision-free route...", fg=THEME_ACCENT_AMBER)
        self.root.update_idletasks()

        # Calculate new A* plan from current robot position to goal
        if self.active_scenario == "hotelroomservice":
            new_plan = replan_hotel_route(start_xy, goal_xy)
        else:
            new_plan = replan_library_route(start_xy, goal_xy)

        if not new_plan or not new_plan.get('success'):
            self.lbl_goal_status.configure(
                text="[!] Replanning Failed: No collision-free route to destination",
                fg=THEME_ACCENT_RED
            )
            self._update_badges("PLAN FAILED", "#e06c75")
            return

        # Stage B: A* Search result update
        self.planner_data = new_plan
        self.active_a_star_waypoints = [list(wp) for wp in new_plan['waypoints']]

        # Update controller waypoints dynamically
        self.ctrl.set_waypoints(self.active_a_star_waypoints)

        # Update environment goal coordinates
        self.env.soadrl_sim.robot.gx = goal_xy[0]
        self.env.soadrl_sim.robot.gy = goal_xy[1]

        # Update metrics panel
        self.lbl_plan_status.configure(text="Algorithm: Dynamic A* Search [f(n)=g(n)+h(n)]")
        self.lbl_plan_stats1.configure(
            text="Explored: {:,} cells | Length: {:.2f} m".format(
                new_plan.get('nodes_explored', 0), new_plan.get('path_length_m', 0.0)
            )
        )
        self.lbl_plan_stats2.configure(
            text="Time: {:.1f} ms | Res: 0.10m | Waypoints: {}".format(
                new_plan.get('plan_time_ms', 0.0), len(self.active_a_star_waypoints)
            )
        )

        self.lbl_goal_status.configure(
            text="Route synthesized: {:.2f}m ({} waypoints). Click 'Start Navigation' or 'Resume'.".format(
                new_plan.get('path_length_m', 0.0), len(self.active_a_star_waypoints)
            ),
            fg=THEME_ACCENT_GREEN
        )
        self._update_badges("ROUTE READY", "#43a047")

        # Stage C: Trigger search animation followed by resume
        self.planning_keyframe_idx = 0
        self.is_planning_animating = True
        self._animate_planning_step()

    def on_reset_to_original_pressed(self):
        """Resets destination to canonical scenario goal."""
        self.selected_goal = list(self.original_goal)
        self.selected_goal_label = "Suite 204 Delivery" if self.active_scenario == "hotelroomservice" else "Circulation Counter"
        self._compute_a_star_plan()
        self.reset_simulation()
        self.lbl_goal_status.configure(
            text="Reset to original baseline destination.",
            fg=THEME_ACCENT_BLUE
        )
        self._update_badges("READY", "#9e9e9e")
        self._render_current_frame()

    def _step_simulation_loop(self):
        """Non-blocking step execution scheduled via root.after()."""
        if not self.is_running or self.is_paused:
            return

        if self.current_step >= self.max_steps:
            self._handle_episode_terminal(Timeout(), "TIMEOUT")
            return

        robot = self.env.soadrl_sim.robot
        humans = self.env.soadrl_sim.humans
        robot_pos = [robot.px, robot.py]

        # Compute velocity command from active NavigationController
        action = self.ctrl.act(robot_pos, humans, action_dim=2)
        vx, vy = float(action[0]), float(action[1])

        # Step environment
        ob, rew, done, info = self.env.step(action)
        self.current_step += 1

        new_pos = [robot.px, robot.py]
        self.trajectory.append(new_pos)

        # Context-aware navigation state for evaluator commentary
        tot_speed = math.hypot(vx, vy)
        detour_active = getattr(self.ctrl, 'detour_x', 0.0) != 0.0 or getattr(self.ctrl, 'detour_y', 0.0) != 0.0
        if tot_speed < 0.04 and self.current_step > 5:
            self.nav_state_str = "PREDICTIVE YIELDING (Waiting for crossing pedestrian)"
        elif detour_active:
            self.nav_state_str = "DETOUR ACTIVE (Bypassing static patron/guest cluster)"
        elif self.ctrl.current_wp_idx >= len(self.ctrl.waypoints) - 1:
            dest_name = self.selected_goal_label if self.selected_goal_label else ("SUITE 204" if self.active_scenario == "hotelroomservice" else "CIRCULATION COUNTER")
            self.nav_state_str = "DOCKING AT {}".format(dest_name.upper())
        elif self.active_scenario == "hotelroomservice":
            if robot.px < -6.0:
                self.nav_state_str = "TRANSIT: Reception & Service Hall"
            elif robot.px < 2.0:
                self.nav_state_str = "TRANSIT: Executive Lobby & Suite Corridors"
            else:
                self.nav_state_str = "TRANSIT: East Suite Wing & Room 204 Delivery"
        else:
            if robot.px < -3.2:
                self.nav_state_str = "TRANSIT: Stack Aisle 2 (Narrow Corridor)"
            elif robot.px < 1.0:
                self.nav_state_str = "TRANSIT: Central Cross-Corridor"
            else:
                self.nav_state_str = "TRANSIT: Reading Hall & Foyer"

        self._update_telemetry(vx, vy)
        self._render_current_frame()

        event = info.get('event')
        target_goal = self.selected_goal if self.selected_goal is not None else self.cfg.robot_goal
        dist_to_curr_goal = math.hypot(target_goal[0] - robot.px, target_goal[1] - robot.py)
        if dist_to_curr_goal < 0.35 and self.ctrl.current_wp_idx >= len(self.ctrl.waypoints) - 1:
            done = True
            event = ReachGoal()
        elif isinstance(event, (ReachGoal, Collision, CollisionOtherAgent, Timeout)):
            done = True

        if done:
            status_text = "GOAL REACHED" if isinstance(event, ReachGoal) else (
                "COLLISION" if isinstance(event, (Collision, CollisionOtherAgent)) else "TIMEOUT"
            )
            self._handle_episode_terminal(event, status_text)
        else:
            self.root.after(self.step_delay_ms, self._step_simulation_loop)

    def _handle_episode_terminal(self, event, status_text):
        """Handles completion of an episode."""
        self.is_running = False
        self.is_full_demo_active = False
        self.terminal_event = event
        self.btn_start.configure(text="Finished", state="disabled")
        self.btn_pause.configure(state="disabled")

        badge_colors = {
            "GOAL REACHED": "#43a047",
            "COLLISION": "#c62828",
            "TIMEOUT": "#f4511e"
        }
        bg_col = badge_colors.get(status_text, "#9e9e9e")
        self._update_badges(status_text, bg_col)
        self._render_current_frame()

    def _update_badges(self, status_text, bg_color):
        fg_col = "#ffffff" if bg_color != "#9e9e9e" else "#21252b"
        self.lbl_header_status.configure(text="STATUS: {}".format(status_text), bg=bg_color, fg=fg_col)

    def _update_telemetry(self, vx, vy):
        sim_time = self.current_step * 0.2
        self.lbl_telem_step.configure(
            text="Step: {:3d} / {} | Sim Time: {:5.1f}s / 76.0s".format(
                self.current_step, self.max_steps, sim_time)
        )

        rx, ry = self.env.soadrl_sim.robot.px, self.env.soadrl_sim.robot.py
        target_goal = self.selected_goal if self.selected_goal is not None else self.cfg.robot_goal
        gx, gy = target_goal[0], target_goal[1]
        dist_goal = math.hypot(rx - gx, ry - gy)
        theta_deg = math.degrees(self.env.soadrl_sim.robot.theta)

        self.lbl_telem_pos.configure(
            text="Pose: ({:+5.2f}m, {:+5.2f}m) | th = {:+5.1f} deg".format(rx, ry, theta_deg)
        )
        self.lbl_telem_vel.configure(
            text="Speed: |v|={:4.2f} m/s (vx={:+4.2f}, vy={:+4.2f})".format(
                math.hypot(vx, vy), vx, vy)
        )
        self.lbl_telem_goal.configure(
            text="Dist to Goal: {:5.2f} m ({:+4.1f}, {:+4.1f})".format(dist_goal, gx, gy)
        )

        n_wps = len(self.ctrl.waypoints)
        curr_idx = min(self.ctrl.current_wp_idx, n_wps - 1)
        if self.active_scenario == "hotelroomservice" and n_wps == 6 and abs(self.ctrl.waypoints[-1][0] - 10.0) < 0.2:
            hotel_wp_names = [
                "WP 0 (Pantry Exit: -7.0m)",
                "WP 1 (Reception Cross: -3.0m)",
                "WP 2 (Lobby Lounge Mid: +1.0m)",
                "WP 3 (North Suite Egress: +5.0m)",
                "WP 4 (East Corridor Approach: +8.0m)",
                "WP 5 (Suite 204 Doorway: +10.0m)"
            ]
            self.lbl_telem_wp.configure(text="Active Waypoint: {}".format(hotel_wp_names[curr_idx]))
        elif n_wps == 7 and abs(self.ctrl.waypoints[-1][0] - 5.5) < 0.2:
            wp_names = [
                "WP 0 (Start Carrel)",
                "WP 1 (Aisle 2 Mid)",
                "WP 2 (Aisle 2 Egress)",
                "WP 3 (Cross-Corridor Upper)",
                "WP 4 (Cross-Corridor Lower)",
                "WP 5 (Reading Hall Transit)",
                "WP 6 (Circulation Desk Dock)"
            ]
            self.lbl_telem_wp.configure(text="Active Waypoint: {}".format(wp_names[curr_idx]))
        else:
            self.lbl_telem_wp.configure(text="Active Waypoint: WP {} / {} -> ({:+.2f}, {:+.2f})".format(
                curr_idx, n_wps - 1, self.ctrl.waypoints[curr_idx][0], self.ctrl.waypoints[curr_idx][1]))
        self.lbl_telem_state.configure(text="Controller State: {}".format(self.nav_state_str))

    # --------------------------------------------------------------------------
    # MAP & ARCHITECTURAL RENDERING ENGINE
    # --------------------------------------------------------------------------
    def _w2px(self, wx, wy):
        """Converts world coordinate (meters) to canvas pixels."""
        px = int(self.orig_x + wx * self.scale_px)
        py = int(self.orig_y - wy * self.scale_px)
        return px, py

    def _px2w(self, px, py):
        """Converts canvas pixels to world coordinates (meters)."""
        wx = (px - self.orig_x) / float(self.scale_px)
        wy = (self.orig_y - py) / float(self.scale_px)
        return wx, wy

    def _render_current_frame(self):
        """Dispatches rendering to active scenario (Library or Hotel)."""
        if self.active_scenario == "hotelroomservice":
            self._render_hotel_frame()
        else:
            self._render_library_frame()

    # --------------------------------------------------------------------------
    # HOTEL RENDERING PIPELINE
    # --------------------------------------------------------------------------
    def _render_hotel_frame(self):
        """Draws the luxury Grand Hotel corridor, lounge, and suites."""
        img = np.full((self.canvas_height, self.canvas_width, 3), HOTEL_FLOOR_MARBLE, dtype=np.uint8)

        # 1. Italian marble floor grout lines
        for gx in range(0, self.canvas_width, 36):
            cv2.line(img, (gx, 0), (gx, self.canvas_height), HOTEL_FLOOR_GROUT, 1)
        for gy in range(0, self.canvas_height, 36):
            cv2.line(img, (0, gy), (self.canvas_width, gy), HOTEL_FLOOR_GROUT, 1)

        # 2. Central plush runner carpet
        c_tl = self._w2px(-12.0, 2.7)
        c_br = self._w2px(12.0, -2.7)
        cv2.rectangle(img, (0, c_tl[1]), (self.canvas_width, c_br[1]), HOTEL_CARPET_BASE, -1)
        # Brass transition trim
        cv2.line(img, (0, c_tl[1]), (self.canvas_width, c_tl[1]), HOTEL_BRASS_TRIM, 4)
        cv2.line(img, (0, c_br[1]), (self.canvas_width, c_br[1]), HOTEL_BRASS_TRIM, 4)
        # Inner gold pinstripes
        cv2.line(img, (0, c_tl[1] + 6), (self.canvas_width, c_tl[1] + 6), (70, 210, 245), 1)
        cv2.line(img, (0, c_br[1] - 6), (self.canvas_width, c_br[1] - 6), (70, 210, 245), 1)
        # Repeating diamond pattern
        mid_y = int((c_tl[1] + c_br[1]) / 2.0)
        for dx in range(30, self.canvas_width, 60):
            d_pts = np.array([[dx, mid_y - 8], [dx + 12, mid_y], [dx, mid_y + 8], [dx - 12, mid_y]], dtype=np.int32)
            cv2.polylines(img, [d_pts], isClosed=True, color=HOTEL_CARPET_PATTERN, thickness=1)

        # 3. Outer architectural perimeter walls
        if self.cfg is not None:
            outer_poly = np.array([self._w2px(pt[0], pt[1]) for pt in self.cfg.static_obstacles[0]], dtype=np.int32)
            cv2.polylines(img, [outer_poly], isClosed=True, color=(20, 35, 60), thickness=6)

        # 4. Obstacles
        if self.cfg is not None:
            for idx, poly in enumerate(self.cfg.static_obstacles[1:], start=1):
                pts = np.array([self._w2px(pt[0], pt[1]) for pt in poly], dtype=np.int32)
                x_min, x_max = np.min(pts[:, 0]), np.max(pts[:, 0])
                y_min, y_max = np.min(pts[:, 1]), np.max(pts[:, 1])

                if idx == 1:
                    # Reception Desk
                    cv2.fillPoly(img, [pts + np.array([4, 4], dtype=np.int32)], (180, 190, 200))
                    cv2.fillPoly(img, [pts], HOTEL_RECEPTION_TOP)
                    cv2.polylines(img, [pts], isClosed=True, color=HOTEL_BRASS_TRIM, thickness=2)
                    # Golden Call Bell at (-7.2, 4.8)
                    b_px, b_py = self._w2px(-7.2, 4.8)
                    cv2.circle(img, (b_px, b_py), 6, HOTEL_RECEPTION_BELL, -1)
                    cv2.circle(img, (b_px, b_py), 7, (20, 120, 180), 1)
                    cv2.line(img, (b_px, b_py - 6), (b_px, b_py - 9), (20, 120, 180), 2)
                    # Computer monitor at (-8.7, 4.8)
                    m_px, m_py = self._w2px(-8.7, 4.8)
                    cv2.rectangle(img, (m_px - 8, m_py - 5), (m_px + 8, m_py + 5), HOTEL_MONITOR_BEZEL, -1)
                    cv2.rectangle(img, (m_px - 6, m_py - 4), (m_px + 6, m_py + 4), HOTEL_MONITOR_SCREEN, -1)
                    # Desk blotter at (-7.9, 4.8)
                    bl_px, bl_py = self._w2px(-7.9, 4.8)
                    cv2.rectangle(img, (bl_px - 6, bl_py - 4), (bl_px + 6, bl_py + 4), (40, 70, 120), -1)
                    # Plaque above desk
                    c_x = int(np.mean(pts[:, 0]))
                    cv2.putText(img, "CONCIERGE & RECEPTION", (c_x - 72, y_min - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.32, (30, 45, 80), 1, cv2.LINE_AA)

                elif idx in [2, 3]:
                    # Lobby Lounge Sofas
                    is_left = (idx == 2)
                    cv2.fillPoly(img, [pts + np.array([4, 4], dtype=np.int32)], (180, 190, 200))
                    cv2.fillPoly(img, [pts], HOTEL_SOFA_SAPPHIRE)
                    cv2.polylines(img, [pts], isClosed=True, color=HOTEL_SOFA_BORDER, thickness=2)
                    mid_x = int((x_min + x_max) / 2)
                    cv2.line(img, (mid_x, y_min), (mid_x, y_max), HOTEL_SOFA_BORDER, 1)
                    if is_left:
                        p_px, p_py = self._w2px(-7.0, -5.5)
                        cv2.circle(img, (p_px, p_py), 8, HOTEL_PLANT_POT, -1)
                        cv2.circle(img, (p_px, p_py), 6, HOTEL_PLANT_GREEN, -1)
                    else:
                        t_px, t_py = self._w2px(-2.85, -5.5)
                        cv2.rectangle(img, (t_px - 8, t_py - 10), (t_px + 8, t_py + 10), HOTEL_COFFEE_TABLE, -1)
                        cv2.rectangle(img, (t_px - 6, t_py - 8), (t_px + 6, t_py + 8), HOTEL_TABLE_GLASS, -1)
                        cv2.circle(img, (t_px, t_py), 3, (180, 80, 220), -1)
                        p_px, p_py = self._w2px(0.8, -5.5)
                        cv2.circle(img, (p_px, p_py), 8, HOTEL_PLANT_POT, -1)
                        cv2.circle(img, (p_px, p_py), 6, HOTEL_PLANT_GREEN, -1)
                        # Lounge Label below coffee table
                        cv2.putText(img, "EXECUTIVE LOUNGE", (t_px - 50, y_max + 16), cv2.FONT_HERSHEY_SIMPLEX, 0.32, (30, 45, 80), 1, cv2.LINE_AA)

                elif idx in HOTEL_SUITE_METADATA:
                    suite_no, suite_type, is_north = HOTEL_SUITE_METADATA[idx]
                    cv2.fillPoly(img, [pts + np.array([3, 3], dtype=np.int32)], (180, 190, 200))
                    cv2.fillPoly(img, [pts], HOTEL_WALL_WOOD)
                    cv2.polylines(img, [pts], isClosed=True, color=HOTEL_WALL_BORDER, thickness=2)
                    door_w = 20
                    door_cx = int((x_min + x_max) / 2)
                    door_y1 = y_max - 8 if is_north else y_min
                    door_y2 = y_max if is_north else y_min + 8
                    cv2.rectangle(img, (door_cx - door_w // 2, door_y1), (door_cx + door_w // 2, door_y2), HOTEL_DOOR_MAHOGANY, -1)
                    cv2.polylines(img, [np.array([
                        [door_cx - door_w // 2, door_y1], [door_cx + door_w // 2, door_y1],
                        [door_cx + door_w // 2, door_y2], [door_cx - door_w // 2, door_y2]
                    ], dtype=np.int32)], isClosed=True, color=HOTEL_DOOR_BRASS, thickness=1)
                    plaque_w, plaque_h = 56, 14
                    plaque_x = door_cx - plaque_w // 2
                    plaque_y = door_y1 - 10 if is_north else door_y2 + 2
                    cv2.rectangle(img, (plaque_x, plaque_y), (plaque_x + plaque_w, plaque_y + plaque_h), HOTEL_PLAQUE_BG, -1)
                    cv2.rectangle(img, (plaque_x, plaque_y), (plaque_x + plaque_w, plaque_y + plaque_h), HOTEL_PLAQUE_GOLD, 1)
                    cv2.putText(img, suite_no, (plaque_x + 4, plaque_y + 10), cv2.FONT_HERSHEY_SIMPLEX, 0.28, HOTEL_PLAQUE_GOLD, 1, cv2.LINE_AA)

                elif idx == 10:
                    # Housekeeping Depot
                    cv2.fillPoly(img, [pts + np.array([3, 3], dtype=np.int32)], (180, 190, 200))
                    cv2.fillPoly(img, [pts], (30, 48, 70))
                    cv2.polylines(img, [pts], isClosed=True, color=(50, 80, 110), thickness=2)
                    shelf_y = int((y_min + y_max) / 2)
                    cv2.line(img, (x_min + 6, shelf_y), (x_max - 6, shelf_y), (100, 130, 160), 2)
                    cv2.rectangle(img, (x_min + 10, shelf_y - 8), (x_min + 24, shelf_y - 2), HOTEL_TOWEL_WHITE, -1)
                    cv2.rectangle(img, (x_min + 28, shelf_y - 8), (x_min + 42, shelf_y - 2), HOTEL_TOWEL_TEAL, -1)
                    cv2.rectangle(img, (x_max - 28, shelf_y + 4), (x_max - 10, y_max - 4), HOTEL_HAMPER_COL, -1)
                    c_x = int(np.mean(pts[:, 0]))
                    cv2.putText(img, "HOUSEKEEPING & LINEN", (c_x - 55, y_min - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.30, (30, 60, 90), 1, cv2.LINE_AA)

        # 5. A* Path Planning Visualization Overlay
        if self.view_mode in ["PLANNING", "NAVIGATING"] and self.planner_data is not None:
            self._draw_a_star_overlay(img)

        # 6. Start & Goal Markers
        if self.cfg is not None:
            s_px, s_py = self._w2px(self.cfg.robot_start[0], self.cfg.robot_start[1])
            cv2.rectangle(img, (s_px - 14, s_py - 18), (s_px + 14, s_py + 18), (170, 175, 180), -1)
            cv2.line(img, (s_px, s_py - 18), (s_px, s_py + 18), (110, 115, 120), 2)
            cv2.circle(img, (s_px, s_py), 14, (60, 180, 75), 2, cv2.LINE_AA)
            cv2.circle(img, (s_px, s_py), 6, (60, 180, 75), -1, cv2.LINE_AA)
            cv2.putText(img, "START: Pantry", (s_px - 45, s_py - 24), cv2.FONT_HERSHEY_SIMPLEX, 0.38, (230, 255, 230), 1, cv2.LINE_AA)

            target_goal = self.selected_goal if self.selected_goal is not None else self.cfg.robot_goal
            g_px, g_py = self._w2px(target_goal[0], target_goal[1])
            cv2.rectangle(img, (g_px - 12, g_py - 22), (g_px + 12, g_py + 22), HOTEL_DOOR_MAHOGANY, -1)
            cv2.rectangle(img, (g_px - 12, g_py - 22), (g_px + 12, g_py + 22), HOTEL_DOOR_BRASS, 1)
            cv2.circle(img, (g_px, g_py), 16, (0, 190, 250), 2, cv2.LINE_AA)
            cv2.circle(img, (g_px, g_py), 8, HOTEL_ROBOT_CLOCHE, -1, cv2.LINE_AA)
            cv2.circle(img, (g_px, g_py - 8), 2, HOTEL_ROBOT_HANDLE, -1, cv2.LINE_AA)
            g_lbl = "GOAL: " + (self.selected_goal_label if self.selected_goal_label else "Suite 204")
            cv2.putText(img, g_lbl, (g_px - 55, g_py - 26), cv2.FONT_HERSHEY_SIMPLEX, 0.40, (70, 220, 255), 2, cv2.LINE_AA)

        # 7. Visited Trajectory Trail
        if len(self.trajectory) > 1:
            for i in range(len(self.trajectory) - 1):
                p1 = self._w2px(self.trajectory[i][0], self.trajectory[i][1])
                p2 = self._w2px(self.trajectory[i + 1][0], self.trajectory[i + 1][1])
                cv2.line(img, p1, p2, (30, 180, 245), 2, cv2.LINE_AA)

        # 8. Dynamic Pedestrians with Hotel Roles
        if self.env is not None and hasattr(self.env, "soadrl_sim"):
            self._draw_hotel_pedestrians(img)

        # 9. Hotel Room Service AMR Avatar
        if self.env is not None and hasattr(self.env, "soadrl_sim"):
            self._draw_hotel_robot(img)

        # 10. Interactive Goal Selection Overlay
        if self.is_selecting_goal:
            cv2.rectangle(img, (20, 16), (580, 50), (25, 28, 36), -1)
            cv2.rectangle(img, (20, 16), (580, 50), (0, 190, 255), 2)
            cv2.putText(
                img,
                "[HOTEL SELECTION MODE] CLICK A REACHABLE CORRIDOR LOCATION FOR ROOM SERVICE",
                (30, 38),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.34,
                (0, 230, 255),
                1,
                cv2.LINE_AA
            )
            if self.mouse_hover_coords is not None:
                hx_px, hy_px = self._w2px(self.mouse_hover_coords[0], self.mouse_hover_coords[1])
                if 0 <= hx_px < self.canvas_width and 0 <= hy_px < self.canvas_height:
                    cv2.circle(img, (hx_px, hy_px), 8, (0, 220, 255), 1, cv2.LINE_AA)
                    cv2.drawMarker(img, (hx_px, hy_px), (0, 220, 255), cv2.MARKER_CROSS, 14, 1)

        # 11. HUD Legend
        self._draw_hotel_hud_legend(img)

        # Render on Canvas
        self._last_bgr_img = img.copy()
        rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        pil_img = Image.fromarray(rgb_img)
        self.canvas_photo = ImageTk.PhotoImage(image=pil_img)
        self.canvas.create_image(0, 0, image=self.canvas_photo, anchor="nw")

    def _draw_hotel_robot(self, img):
        if self.env is None or not hasattr(self.env, "soadrl_sim"):
            return
        robot = self.env.soadrl_sim.robot
        rx, ry = self._w2px(robot.px, robot.py)
        rr = max(10, int(robot.radius * self.scale_px))
        theta = robot.theta

        cos_t = math.cos(theta)
        sin_t = math.sin(theta)
        nx = -sin_t
        ny = cos_t
        w1_x = int(rx + nx * (rr + 2))
        w1_y = int(ry - ny * (rr + 2))
        w2_x = int(rx - nx * (rr + 2))
        w2_y = int(ry + ny * (rr + 2))
        cv2.circle(img, (w1_x, w1_y), 3, (30, 30, 30), -1)
        cv2.circle(img, (w2_x, w2_y), 3, (30, 30, 30), -1)

        cv2.circle(img, (rx, ry), rr, HOTEL_ROBOT_SILVER, -1)
        cv2.circle(img, (rx, ry), rr, (140, 145, 150), 2)

        cloche_r = max(5, int(rr * 0.55))
        cv2.circle(img, (rx, ry), cloche_r, HOTEL_ROBOT_CLOCHE, -1)
        cv2.circle(img, (rx, ry), cloche_r, (160, 165, 170), 1)
        cv2.circle(img, (rx, ry), 2, HOTEL_ROBOT_HANDLE, -1)

        head_x = int(rx + cos_t * (rr - 2))
        head_y = int(ry - sin_t * (rr - 2))
        cv2.circle(img, (head_x, head_y), 3, HOTEL_ROBOT_AMBER, -1)

        ray_x = int(rx + cos_t * (rr + 12))
        ray_y = int(ry - sin_t * (rr + 12))
        cv2.line(img, (rx, ry), (ray_x, ray_y), (255, 255, 255), 2, cv2.LINE_AA)
        cv2.putText(img, "AMR: Service", (rx - 36, ry - rr - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.34, (255, 255, 255), 1, cv2.LINE_AA)

    def _draw_hotel_pedestrians(self, img):
        if self.env is None or not hasattr(self.env, "soadrl_sim"):
            return
        sim = self.env.soadrl_sim
        for i, h in enumerate(sim.humans):
            hx, hy = self._w2px(h.px, h.py)
            hr = max(6, int(h.radius * self.scale_px))
            speed = math.hypot(h.vx, h.vy)

            role = 'pedestrian_guest'
            if self.cfg and hasattr(self.cfg, 'base_humans') and i < len(self.cfg.base_humans):
                role = self.cfg.base_humans[i].get('role', 'pedestrian_guest')

            if role == 'pedestrian_housekeeping':
                cv2.circle(img, (hx, hy), hr, ROLE_HOUSEKEEPING, -1)
                cv2.circle(img, (hx, hy), hr, (20, 90, 50), 1)
                if speed > 0.05:
                    dir_x = h.vx / speed
                    dir_y = -h.vy / speed
                else:
                    dir_x, dir_y = 1.0, 0.0
                cart_cx = int(hx + dir_x * (hr + 12))
                cart_cy = int(hy + dir_y * (hr + 12))
                cart_w, cart_h = 16, 14
                cv2.rectangle(img, (cart_cx - cart_w // 2, cart_cy - cart_h // 2),
                              (cart_cx + cart_w // 2, cart_cy + cart_h // 2), ROLE_LINEN_CART, -1)
                cv2.rectangle(img, (cart_cx - 6, cart_cy - 4), (cart_cx - 1, cart_cy + 4), HOTEL_TOWEL_WHITE, -1)
                cv2.putText(img, "Housekeeping", (hx - 36, hy - hr - 4), cv2.FONT_HERSHEY_SIMPLEX, 0.30, (255, 255, 255), 1, cv2.LINE_AA)
            else:
                cv2.circle(img, (hx, hy), hr, ROLE_GUEST, -1)
                cv2.circle(img, (hx, hy), hr, (20, 60, 100), 1)
                if speed > 0.05:
                    dir_x = -h.vx / speed
                    dir_y = h.vy / speed
                else:
                    dir_x, dir_y = -1.0, 0.0
                sc_cx = int(hx + dir_x * (hr + 10))
                sc_cy = int(hy + dir_y * (hr + 10))
                cv2.rectangle(img, (sc_cx - 5, sc_cy - 4), (sc_cx + 5, sc_cy + 4), ROLE_SUITCASE, -1)
                cv2.line(img, (sc_cx, sc_cy), (hx, hy), (50, 50, 50), 1)
                cv2.putText(img, "Guest", (hx - 14, hy - hr - 4), cv2.FONT_HERSHEY_SIMPLEX, 0.30, (255, 255, 255), 1, cv2.LINE_AA)

            if speed > 0.05:
                v_end_x = int(hx + h.vx * self.scale_px * 0.4)
                v_end_y = int(hy - h.vy * self.scale_px * 0.4)
                cv2.arrowedLine(img, (hx, hy), (v_end_x, v_end_y), (255, 255, 255), 1, tipLength=0.3)

    def _draw_hotel_hud_legend(self, img):
        cv2.rectangle(img, (20, self.canvas_height - 38), (560, self.canvas_height - 12), (25, 28, 34), -1)
        cv2.rectangle(img, (20, self.canvas_height - 38), (560, self.canvas_height - 12), (50, 55, 65), 1)
        cv2.circle(img, (32, self.canvas_height - 25), 6, HOTEL_ROBOT_SILVER, -1)
        cv2.circle(img, (32, self.canvas_height - 25), 3, HOTEL_ROBOT_CLOCHE, -1)
        cv2.putText(img, "AMR Cloche (0.6m)", (44, self.canvas_height - 21), cv2.FONT_HERSHEY_SIMPLEX, 0.32, (220, 225, 230), 1)
        cv2.circle(img, (155, self.canvas_height - 25), 6, ROLE_GUEST, -1)
        cv2.putText(img, "Guest + Luggage", (167, self.canvas_height - 21), cv2.FONT_HERSHEY_SIMPLEX, 0.32, (220, 225, 230), 1)
        cv2.circle(img, (275, self.canvas_height - 25), 6, ROLE_HOUSEKEEPING, -1)
        cv2.putText(img, "Housekeeping + Cart", (287, self.canvas_height - 21), cv2.FONT_HERSHEY_SIMPLEX, 0.32, (220, 225, 230), 1)
        cv2.rectangle(img, (415, self.canvas_height - 29), (427, self.canvas_height - 21), HOTEL_WALL_WOOD, -1)
        cv2.putText(img, "Suites", (433, self.canvas_height - 21), cv2.FONT_HERSHEY_SIMPLEX, 0.32, (220, 225, 230), 1)
        cv2.line(img, (485, self.canvas_height - 25), (505, self.canvas_height - 25), (40, 210, 80), 2)
        cv2.putText(img, "A* Route", (512, self.canvas_height - 21), cv2.FONT_HERSHEY_SIMPLEX, 0.32, (220, 225, 230), 1)

    # --------------------------------------------------------------------------
    # LIBRARY RENDERING PIPELINE
    # --------------------------------------------------------------------------
    def _render_library_frame(self):
        """Draws the realistic academic library floor plan and all active dynamic elements."""
        img = np.full((self.canvas_height, self.canvas_width, 3), FLOOR_BASE, dtype=np.uint8)

        # 1. Warm Parquet Hardwood Flooring Texture
        plank_h = 32
        for y_top in range(0, self.canvas_height, plank_h):
            row_idx = y_top // plank_h
            if row_idx % 2 == 1:
                cv2.rectangle(img, (0, y_top), (self.canvas_width, min(self.canvas_height, y_top + plank_h)), FLOOR_PLANK_ALT, -1)
            shift = (row_idx * 57) % 110
            for x_seam in range(shift, self.canvas_width, 110):
                cv2.line(img, (x_seam, y_top), (x_seam, min(self.canvas_height, y_top + plank_h)), FLOOR_SEAM, 1)

        # 2. Outer Baseboard & Architectural Perimeter Walls
        if self.cfg is not None:
            outer_poly = np.array([self._w2px(pt[0], pt[1]) for pt in self.cfg.static_obstacles[0]], dtype=np.int32)
            cv2.polylines(img, [outer_poly], isClosed=True, color=BASEBOARD_COL, thickness=6)

        # 3. Static Architectural Elements
        if self.cfg is not None:
            for idx, poly in enumerate(self.cfg.static_obstacles[1:], start=1):
                pts = np.array([self._w2px(pt[0], pt[1]) for pt in poly], dtype=np.int32)
                if idx in [1, 2, 3]:
                    self._draw_bookshelf(img, poly, idx)
                elif idx == 4:
                    self._draw_bookshelf(img, poly, idx)
                elif idx == 5:
                    self._draw_archive_reading_table(img, poly)
                elif idx == 6:
                    self._draw_reference_study_zone(img, poly)
                elif idx == 7:
                    self._draw_study_table_a(img, poly)
                elif idx == 8:
                    self._draw_group_study_table_b(img, poly)
                elif idx == 9:
                    self._draw_structural_pillar(img, pts, "A")
                elif idx == 10:
                    self._draw_structural_pillar(img, pts, "B")
                elif idx == 11:
                    self._draw_new_arrivals_rack(img, poly)
                else:
                    self._draw_bookshelf(img, poly, idx)

        # 4. Overhead Architectural Section Labels
        self._draw_section_labels(img)

        # 5. A* Path Planning Visualization Overlay
        if self.view_mode in ["PLANNING", "NAVIGATING"] and self.planner_data is not None:
            self._draw_a_star_overlay(img)

        # 6. Start & Goal Visual Markers
        if self.cfg is not None:
            s_px, s_py = self._w2px(self.cfg.robot_start[0], self.cfg.robot_start[1])
            cv2.circle(img, (s_px, s_py), 14, (60, 180, 75), 2, cv2.LINE_AA)
            cv2.circle(img, (s_px, s_py), 7, (60, 180, 75), -1, cv2.LINE_AA)
            cv2.putText(img, "START: Aisle 2", (s_px - 40, s_py - 18), cv2.FONT_HERSHEY_SIMPLEX, 0.40, (30, 120, 40), 1, cv2.LINE_AA)

            target_goal = self.selected_goal if self.selected_goal is not None else self.cfg.robot_goal
            g_px, g_py = self._w2px(target_goal[0], target_goal[1])
            cv2.circle(img, (g_px, g_py), 16, (0, 190, 250), 2, cv2.LINE_AA)
            cv2.circle(img, (g_px, g_py), 9, (0, 190, 250), -1, cv2.LINE_AA)
            g_lbl = "GOAL: " + (self.selected_goal_label if self.selected_goal_label else "Circulation Desk")
            cv2.putText(img, g_lbl, (g_px - 70, g_py - 22), cv2.FONT_HERSHEY_SIMPLEX, 0.40, (0, 140, 200), 2, cv2.LINE_AA)

        # 7. Visited Trajectory Trail
        if len(self.trajectory) > 1:
            for i in range(len(self.trajectory) - 1):
                p1 = self._w2px(self.trajectory[i][0], self.trajectory[i][1])
                p2 = self._w2px(self.trajectory[i + 1][0], self.trajectory[i + 1][1])
                cv2.line(img, p1, p2, ROBOT_TRAIL, 2, cv2.LINE_AA)

        # 8. Dynamic Pedestrians with Human Shapes & Roles
        if self.env is not None and hasattr(self.env, "soadrl_sim"):
            self._draw_pedestrians(img)

        # 9. Autonomous Mobile Robot (AMR-01) with Wheels & Heading
        if self.env is not None and hasattr(self.env, "soadrl_sim"):
            self._draw_robot_amr(img)

        # 10. Interactive Goal Selection Overlay (when selection active)
        if self.is_selecting_goal:
            cv2.rectangle(img, (20, 16), (580, 50), (25, 28, 36), -1)
            cv2.rectangle(img, (20, 16), (580, 50), (0, 190, 255), 2)
            cv2.putText(
                img,
                "[SELECTION MODE] CLICK A REACHABLE MAP LOCATION FOR NEW GOAL",
                (30, 38),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.38,
                (0, 230, 255),
                1,
                cv2.LINE_AA
            )
            if self.mouse_hover_coords is not None:
                hx_px, hy_px = self._w2px(self.mouse_hover_coords[0], self.mouse_hover_coords[1])
                if 0 <= hx_px < self.canvas_width and 0 <= hy_px < self.canvas_height:
                    cv2.circle(img, (hx_px, hy_px), 8, (0, 220, 255), 1, cv2.LINE_AA)
                    cv2.drawMarker(img, (hx_px, hy_px), (0, 220, 255), cv2.MARKER_CROSS, 14, 1)

        # 11. Bottom HUD Legend & Calibrated Scale Bar
        self._draw_hud_legend(img)

        # Convert OpenCV BGR to RGB -> ImageTk and render on Canvas
        self._last_bgr_img = img.copy()
        rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        pil_img = Image.fromarray(rgb_img)
        self.canvas_photo = ImageTk.PhotoImage(image=pil_img)
        self.canvas.create_image(0, 0, image=self.canvas_photo, anchor="nw")

    def _draw_bookshelf(self, img, poly, idx):
        pts = np.array([self._w2px(pt[0], pt[1]) for pt in poly], dtype=np.int32)
        shadow_pts = pts + np.array([4, 4], dtype=np.int32)
        cv2.fillPoly(img, [shadow_pts], SHELF_SHADOW)
        cv2.fillPoly(img, [pts], SHELF_BODY)
        cv2.polylines(img, [pts], isClosed=True, color=SHELF_BORDER, thickness=2)

        x_min, x_max = np.min(pts[:, 0]), np.max(pts[:, 0])
        y_min, y_max = np.min(pts[:, 1]), np.max(pts[:, 1])
        book_colors = [
            (35, 60, 160), (45, 140, 80), (160, 70, 40),
            (30, 130, 180), (140, 40, 130), (50, 50, 180),
            (40, 110, 50), (120, 90, 30), (150, 120, 60)
        ]
        np.random.seed(100 + idx)
        cur_x = x_min + 6
        while cur_x < x_max - 8:
            b_w = np.random.randint(6, 13)
            if cur_x + b_w > x_max - 6:
                b_w = (x_max - 6) - cur_x
            if b_w < 4:
                break
            b_col = book_colors[np.random.randint(0, len(book_colors))]
            cv2.rectangle(img, (cur_x, y_min + 4), (cur_x + b_w, y_max - 4), b_col, -1)
            cv2.rectangle(img, (cur_x, y_min + 4), (cur_x + b_w, y_max - 4), (20, 20, 20), 1)
            cur_x += b_w + 1

        shelf_names = {
            1: "STACK A1: Computer Science & AI",
            2: "STACK A2: Robotics & Automation",
            3: "STACK A3: Mathematics & Stats",
            4: "STACK B1: Engineering Journals"
        }
        name = shelf_names.get(idx, "STACK {}".format(idx))
        c_x = int(np.mean(pts[:, 0]))
        c_y = int(np.mean(pts[:, 1]))
        font = cv2.FONT_HERSHEY_SIMPLEX
        scale = 0.30
        (tw, th), _ = cv2.getTextSize(name, font, scale, 1)
        bg_x1, bg_y1 = c_x - tw // 2 - 4, c_y - th // 2 - 2
        bg_x2, bg_y2 = c_x + tw // 2 + 4, c_y + th // 2 + 2
        cv2.rectangle(img, (bg_x1, bg_y1), (bg_x2, bg_y2), (10, 15, 25), -1)
        cv2.rectangle(img, (bg_x1, bg_y1), (bg_x2, bg_y2), (0, 215, 255), 1)
        cv2.putText(img, name, (c_x - tw // 2, c_y + th // 2), font, scale, (0, 215, 255), 1, cv2.LINE_AA)

    def _draw_archive_reading_table(self, img, poly):
        pts = np.array([self._w2px(pt[0], pt[1]) for pt in poly], dtype=np.int32)
        shadow_pts = pts + np.array([4, 4], dtype=np.int32)
        cv2.fillPoly(img, [shadow_pts], SHELF_SHADOW)
        cv2.fillPoly(img, [pts], TABLE_TOP)
        cv2.polylines(img, [pts], isClosed=True, color=TABLE_BORDER, thickness=2)

        x_min, x_max = np.min(pts[:, 0]), np.max(pts[:, 0])
        y_min, y_max = np.min(pts[:, 1]), np.max(pts[:, 1])
        c_x, c_y = (x_min + x_max) // 2, (y_min + y_max) // 2
        font = cv2.FONT_HERSHEY_SIMPLEX
        scale = 0.32
        text = "ARCHIVE READING TABLE"
        (tw, th), _ = cv2.getTextSize(text, font, scale, 1)
        bg_x1, bg_y1 = c_x - tw // 2 - 4, c_y - th // 2 - 2
        bg_x2, bg_y2 = c_x + tw // 2 + 4, c_y + th // 2 + 2
        cv2.rectangle(img, (bg_x1, bg_y1), (bg_x2, bg_y2), (15, 25, 40), -1)
        cv2.rectangle(img, (bg_x1, bg_y1), (bg_x2, bg_y2), (0, 200, 240), 1)
        cv2.putText(img, text, (c_x - tw // 2, c_y + th // 2), font, scale, (0, 220, 255), 1, cv2.LINE_AA)

        for cx in [x_min + 20, (x_min + x_max) // 2, x_max - 20]:
            cv2.rectangle(img, (cx - 7, y_min - 6), (cx + 7, y_min - 2), CHAIR_WOOD, -1)
            cv2.rectangle(img, (cx - 7, y_max + 2), (cx + 7, y_max + 6), CHAIR_WOOD, -1)

    def _draw_reference_study_zone(self, img, poly):
        pts = np.array([self._w2px(pt[0], pt[1]) for pt in poly], dtype=np.int32)
        shadow_pts = pts + np.array([4, 4], dtype=np.int32)
        cv2.fillPoly(img, [shadow_pts], SHELF_SHADOW)
        cv2.fillPoly(img, [pts], TABLE_TOP)
        cv2.polylines(img, [pts], isClosed=True, color=TABLE_BORDER, thickness=2)

        x_min, x_max = np.min(pts[:, 0]), np.max(pts[:, 0])
        y_min, y_max = np.min(pts[:, 1]), np.max(pts[:, 1])
        c_x, c_y = (x_min + x_max) // 2, (y_min + y_max) // 2
        font = cv2.FONT_HERSHEY_SIMPLEX
        scale = 0.32
        text = "REFERENCE STUDY ZONE"
        (tw, th), _ = cv2.getTextSize(text, font, scale, 1)
        bg_x1, bg_y1 = c_x - tw // 2 - 4, c_y - th // 2 - 2
        bg_x2, bg_y2 = c_x + tw // 2 + 4, c_y + th // 2 + 2
        cv2.rectangle(img, (bg_x1, bg_y1), (bg_x2, bg_y2), (15, 25, 40), -1)
        cv2.rectangle(img, (bg_x1, bg_y1), (bg_x2, bg_y2), (255, 255, 255), 1)
        cv2.putText(img, text, (c_x - tw // 2, c_y + th // 2), font, scale, (255, 255, 255), 1, cv2.LINE_AA)

        for cx in [x_min + 25, x_min + 75, x_max - 25]:
            cv2.rectangle(img, (cx - 7, y_min - 6), (cx + 7, y_min - 2), CHAIR_WOOD, -1)
            cv2.rectangle(img, (cx - 7, y_max + 2), (cx + 7, y_max + 6), CHAIR_WOOD, -1)

    def _draw_study_table_a(self, img, poly):
        pts = np.array([self._w2px(pt[0], pt[1]) for pt in poly], dtype=np.int32)
        shadow_pts = pts + np.array([4, 4], dtype=np.int32)
        cv2.fillPoly(img, [shadow_pts], SHELF_SHADOW)
        cv2.fillPoly(img, [pts], TABLE_TOP)
        cv2.polylines(img, [pts], isClosed=True, color=TABLE_BORDER, thickness=2)

        x_min, x_max = np.min(pts[:, 0]), np.max(pts[:, 0])
        y_min, y_max = np.min(pts[:, 1]), np.max(pts[:, 1])
        c_x, c_y = (x_min + x_max) // 2, (y_min + y_max) // 2

        cv2.rectangle(img, (x_min + 30, y_min + 8), (x_min + 45, y_min + 20), (240, 240, 240), -1)
        cv2.rectangle(img, (x_min + 52, y_min + 8), (x_min + 65, y_min + 20), (50, 140, 70), -1)
        cv2.rectangle(img, (x_min + 70, y_min + 8), (x_min + 84, y_min + 20), (60, 60, 60), -1)

        font = cv2.FONT_HERSHEY_SIMPLEX
        scale = 0.30
        text = "STUDY TABLE A"
        (tw, th), _ = cv2.getTextSize(text, font, scale, 1)
        bg_x1, bg_y1 = c_x - tw // 2 - 4, y_max - 18
        bg_x2, bg_y2 = c_x + tw // 2 + 4, y_max - 4
        cv2.rectangle(img, (bg_x1, bg_y1), (bg_x2, bg_y2), (15, 25, 40), -1)
        cv2.rectangle(img, (bg_x1, bg_y1), (bg_x2, bg_y2), (0, 200, 240), 1)
        cv2.putText(img, text, (c_x - tw // 2, y_max - 8), font, scale, (0, 220, 255), 1, cv2.LINE_AA)

        for cx in [x_min + 25, x_min + 60, x_max - 25]:
            cv2.rectangle(img, (cx - 7, y_min - 6), (cx + 7, y_min - 2), CHAIR_WOOD, -1)
            cv2.rectangle(img, (cx - 7, y_max + 2), (cx + 7, y_max + 6), CHAIR_WOOD, -1)

    def _draw_group_study_table_b(self, img, poly):
        pts = np.array([self._w2px(pt[0], pt[1]) for pt in poly], dtype=np.int32)
        shadow_pts = pts + np.array([4, 4], dtype=np.int32)
        cv2.fillPoly(img, [shadow_pts], SHELF_SHADOW)
        cv2.fillPoly(img, [pts], TABLE_TOP)
        cv2.polylines(img, [pts], isClosed=True, color=TABLE_BORDER, thickness=2)

        x_min, x_max = np.min(pts[:, 0]), np.max(pts[:, 0])
        y_min, y_max = np.min(pts[:, 1]), np.max(pts[:, 1])
        c_x, c_y = (x_min + x_max) // 2, (y_min + y_max) // 2

        cv2.rectangle(img, (c_x - 12, y_min + 10), (c_x + 12, y_min + 24), (245, 245, 245), -1)
        cv2.circle(img, (c_x, y_min + 17), 3, (0, 200, 255), -1)

        font = cv2.FONT_HERSHEY_SIMPLEX
        scale = 0.30
        text = "GROUP STUDY TABLE B"
        (tw, th), _ = cv2.getTextSize(text, font, scale, 1)
        bg_x1, bg_y1 = c_x - tw // 2 - 4, y_max - 18
        bg_x2, bg_y2 = c_x + tw // 2 + 4, y_max - 4
        cv2.rectangle(img, (bg_x1, bg_y1), (bg_x2, bg_y2), (15, 25, 40), -1)
        cv2.rectangle(img, (bg_x1, bg_y1), (bg_x2, bg_y2), (0, 200, 240), 1)
        cv2.putText(img, text, (c_x - tw // 2, y_max - 8), font, scale, (0, 220, 255), 1, cv2.LINE_AA)

        for cx in [x_min + 25, x_min + 60, x_max - 25]:
            cv2.rectangle(img, (cx - 7, y_min - 6), (cx + 7, y_min - 2), CHAIR_WOOD, -1)
            cv2.rectangle(img, (cx - 7, y_max + 2), (cx + 7, y_max + 6), CHAIR_WOOD, -1)

    def _draw_structural_pillar(self, img, pts, letter):
        shadow_pts = pts + np.array([4, 4], dtype=np.int32)
        cv2.fillPoly(img, [shadow_pts], SHELF_SHADOW)
        cv2.fillPoly(img, [pts], PILLAR_STONE)
        cv2.polylines(img, [pts], isClosed=True, color=PILLAR_BORDER, thickness=2)

        c_x = int(np.mean(pts[:, 0]))
        c_y = int(np.mean(pts[:, 1]))
        cv2.circle(img, (c_x, c_y), 9, (90, 80, 70), -1)
        cv2.circle(img, (c_x, c_y), 9, (200, 200, 200), 1)
        cv2.putText(img, letter, (c_x - 4, c_y + 4), cv2.FONT_HERSHEY_SIMPLEX, 0.30, (255, 255, 255), 1, cv2.LINE_AA)
        cv2.putText(img, "Pillar {}".format(letter), (c_x - 18, c_y - 14), cv2.FONT_HERSHEY_SIMPLEX, 0.28, (120, 110, 100), 1, cv2.LINE_AA)

    def _draw_new_arrivals_rack(self, img, poly):
        pts = np.array([self._w2px(pt[0], pt[1]) for pt in poly], dtype=np.int32)
        shadow_pts = pts + np.array([4, 4], dtype=np.int32)
        cv2.fillPoly(img, [shadow_pts], SHELF_SHADOW)
        cv2.fillPoly(img, [pts], (40, 45, 55))
        cv2.polylines(img, [pts], isClosed=True, color=(10, 15, 25), thickness=2)

        x_min, x_max = np.min(pts[:, 0]), np.max(pts[:, 0])
        y_min, y_max = np.min(pts[:, 1]), np.max(pts[:, 1])
        tier_h = (y_max - y_min) // 3
        tier_colors = [(0, 180, 240), (40, 80, 200), (120, 40, 120)]
        for t_idx in range(3):
            t_y1 = y_min + t_idx * tier_h + 2
            t_y2 = t_y1 + tier_h - 4
            cv2.rectangle(img, (x_min + 3, t_y1), (x_max // 2 - 2, t_y2), tier_colors[t_idx], -1)
            cv2.rectangle(img, (x_max // 2 + 2, t_y1), (x_max - 3, t_y2), tier_colors[t_idx], -1)

        c_x = int(np.mean(pts[:, 0]))
        cv2.putText(img, "NEW ARRIVALS", (c_x - 22, y_min - 4), cv2.FONT_HERSHEY_SIMPLEX, 0.24, (30, 40, 60), 1, cv2.LINE_AA)

    def _draw_section_labels(self, img):
        font = cv2.FONT_HERSHEY_SIMPLEX
        scale = 0.32
        cv2.putText(img, "WEST WING: BOOK STACKS", (self._w2px(-7.5, 4.8)[0], self._w2px(-7.5, 4.8)[1]), font, scale, (140, 130, 120), 1, cv2.LINE_AA)
        cv2.putText(img, "EAST WING: ARCHIVES", (self._w2px(0.0, 4.8)[0], self._w2px(0.0, 4.8)[1]), font, scale, (140, 130, 120), 1, cv2.LINE_AA)
        cv2.putText(img, "CENTRAL CROSS-CORRIDOR", (self._w2px(-2.2, 3.8)[0], self._w2px(-2.2, 3.8)[1]), font, scale, (160, 150, 140), 1, cv2.LINE_AA)
        cv2.putText(img, "SOUTHERN STUDY & READING HALL", (self._w2px(-6.0, -2.8)[0], self._w2px(-6.0, -2.8)[1]), font, scale, (140, 130, 120), 1, cv2.LINE_AA)
        cv2.putText(img, "CIRCULATION FOYER", (self._w2px(2.8, -2.8)[0], self._w2px(2.8, -2.8)[1]), font, scale, (140, 130, 120), 1, cv2.LINE_AA)

    def _draw_a_star_overlay(self, img):
        if self.planner_data is None:
            return

        keyframes = self.planner_data.get('animation_keyframes', [])
        if self.is_planning_animating and keyframes:
            k_idx = min(self.planning_keyframe_idx, len(keyframes) - 1)
            frame = keyframes[k_idx]
            explored_count = frame.get('explored_count', 0)
            explored_cells = self.planner_data.get('explored_order', [])[:explored_count]

            overlay = img.copy()
            for r, c in explored_cells:
                wx = self.planner_data.get('start_xy', [-8.0, 3.5])[0]
                res = self.planner_data.get('grid_resolution', 0.10)
                px = int(self.orig_x + (self.world_min_x + (c + 0.5) * res) * self.scale_px)
                py = int(self.orig_y - (self.world_max_y - (r + 0.5) * res) * self.scale_px)
                cv2.circle(overlay, (px, py), 2, (240, 220, 180), -1)

            for r, c in frame.get('open_set', []):
                res = self.planner_data.get('grid_resolution', 0.10)
                px = int(self.orig_x + (self.world_min_x + (c + 0.5) * res) * self.scale_px)
                py = int(self.orig_y - (self.world_max_y - (r + 0.5) * res) * self.scale_px)
                cv2.circle(overlay, (px, py), 3, (120, 220, 255), -1)

            cv2.addWeighted(overlay, 0.40, img, 0.60, 0, img)

        path_coords = self.planner_data.get('path_coords', [])
        if len(path_coords) > 1:
            overlay = img.copy()
            for i in range(len(path_coords) - 1):
                p1 = self._w2px(path_coords[i][0], path_coords[i][1])
                p2 = self._w2px(path_coords[i + 1][0], path_coords[i + 1][1])
                cv2.line(overlay, p1, p2, (0, 255, 128), 6, cv2.LINE_AA)
            cv2.addWeighted(overlay, 0.35, img, 0.65, 0, img)

        wps = self.planner_data.get('waypoints', [])
        if len(wps) > 1:
            for i in range(len(wps) - 1):
                p1 = self._w2px(wps[i][0], wps[i][1])
                p2 = self._w2px(wps[i + 1][0], wps[i + 1][1])
                cv2.line(img, p1, p2, (50, 220, 40), 3, cv2.LINE_AA)

            for i, wp in enumerate(wps):
                w_px, w_py = self._w2px(wp[0], wp[1])
                cv2.circle(img, (w_px, w_py), 5, (0, 215, 255), -1)
                cv2.circle(img, (w_px, w_py), 5, (0, 0, 0), 1)

    def _draw_robot_amr(self, img):
        if self.env is None or not hasattr(self.env, "soadrl_sim"):
            return
        robot = self.env.soadrl_sim.robot
        rx, ry = self._w2px(robot.px, robot.py)
        rr = max(8, int(robot.radius * self.scale_px))
        theta = robot.theta

        cos_t = math.cos(theta)
        sin_t = math.sin(theta)
        w_off_x = int(-sin_t * (rr + 2))
        w_off_y = int(-cos_t * (rr + 2))
        cv2.circle(img, (rx + w_off_x, ry + w_off_y), 3, ROBOT_WHEEL, -1)
        cv2.circle(img, (rx - w_off_x, ry - w_off_y), 3, ROBOT_WHEEL, -1)

        cv2.circle(img, (rx, ry), rr, ROBOT_BLUE, -1)
        cv2.circle(img, (rx, ry), rr, (255, 255, 255), 2)
        cv2.circle(img, (rx, ry), max(3, int(rr * 0.40)), ROBOT_LIDAR, -1)

        arr_len = int(rr * 1.5)
        arr_end_x = int(rx + cos_t * arr_len)
        arr_end_y = int(ry - sin_t * arr_len)
        cv2.line(img, (rx, ry), (arr_end_x, arr_end_y), ROBOT_HEADING, 2, cv2.LINE_AA)
        cv2.circle(img, (arr_end_x, arr_end_y), 2, ROBOT_HEADING, -1)
        cv2.putText(img, "AMR", (rx - 12, ry - rr - 4), cv2.FONT_HERSHEY_SIMPLEX, 0.28, (0, 80, 160), 1, cv2.LINE_AA)

    def _draw_pedestrians(self, img):
        if self.env is None or not hasattr(self.env, "soadrl_sim"):
            return
        sim = self.env.soadrl_sim
        for i, h in enumerate(sim.humans):
            hx, hy = self._w2px(h.px, h.py)
            hr = max(6, int(h.radius * self.scale_px))

            role_cols = [ROLE_PATRON, ROLE_STUDENT, ROLE_LIBRARIAN, ROLE_RESEARCHER, ROLE_STAFF]
            col = role_cols[i % len(role_cols)]

            cv2.circle(img, (hx, hy), hr, col, -1)
            cv2.circle(img, (hx, hy), hr, (20, 20, 20), 2)

            speed = math.hypot(h.vx, h.vy)
            if speed > 0.05:
                v_len = int(speed * 20.0)
                vx_norm = h.vx / speed
                vy_norm = h.vy / speed
                v_end_x = int(hx + vx_norm * v_len)
                v_end_y = int(hy - vy_norm * v_len)
                cv2.arrowedLine(img, (hx, hy), (v_end_x, v_end_y), (30, 30, 30), 1, tipLength=0.3)

            role_names = ["P1: Patron", "P2: Student", "P3: Librarian", "P4: Researcher", "P5: Staff"]
            r_name = role_names[i] if i < len(role_names) else "Pedestrian {}".format(i + 1)
            cv2.putText(img, r_name, (hx - 22, hy - hr - 4), cv2.FONT_HERSHEY_SIMPLEX, 0.26, (50, 50, 50), 1, cv2.LINE_AA)

    def _draw_hud_legend(self, img):
        cv2.rectangle(img, (20, self.canvas_height - 38), (450, self.canvas_height - 12), (25, 28, 34), -1)
        cv2.rectangle(img, (20, self.canvas_height - 38), (450, self.canvas_height - 12), (50, 55, 65), 1)
        cv2.circle(img, (32, self.canvas_height - 25), 5, ROBOT_BLUE, -1)
        cv2.putText(img, "AMR (0.6m)", (42, self.canvas_height - 21), cv2.FONT_HERSHEY_SIMPLEX, 0.32, (220, 225, 230), 1)
        cv2.circle(img, (108, self.canvas_height - 25), 5, ROLE_PATRON, -1)
        cv2.putText(img, "Patrons (0.6m)", (118, self.canvas_height - 21), cv2.FONT_HERSHEY_SIMPLEX, 0.32, (220, 225, 230), 1)
        cv2.rectangle(img, (190, self.canvas_height - 29), (200, self.canvas_height - 21), SHELF_BODY, -1)
        cv2.putText(img, "Book Stacks", (206, self.canvas_height - 21), cv2.FONT_HERSHEY_SIMPLEX, 0.32, (220, 225, 230), 1)
        cv2.rectangle(img, (270, self.canvas_height - 29), (280, self.canvas_height - 21), TABLE_TOP, -1)
        cv2.putText(img, "Study Desks", (286, self.canvas_height - 21), cv2.FONT_HERSHEY_SIMPLEX, 0.32, (220, 225, 230), 1)
        cv2.line(img, (350, self.canvas_height - 25), (368, self.canvas_height - 25), (50, 220, 40), 2)
        cv2.putText(img, "A* Route", (374, self.canvas_height - 21), cv2.FONT_HERSHEY_SIMPLEX, 0.32, (220, 225, 230), 1)

    # --------------------------------------------------------------------------
    # QUANTITATIVE BENCHMARK WORKER
    # --------------------------------------------------------------------------
    def on_run_benchmark_pressed(self):
        """Launches the 20-seed benchmark across EASY, MEDIUM, and HARD in a background thread."""
        if self.is_benchmark_running:
            return
        if self.is_running:
            self.on_pause_pressed()

        self.is_benchmark_running = True
        self.btn_benchmark.configure(state="disabled", text="Evaluating 60 Episodes...")
        self.lbl_bench_progress.configure(text="Benchmark in progress... evaluating seeds 42-61", fg=THEME_ACCENT_AMBER)

        bench_thread = threading.Thread(target=self._run_benchmark_worker)
        bench_thread.daemon = True
        bench_thread.start()

    def _run_benchmark_worker(self):
        results = {}
        sc_id = self.active_scenario
        cfg = get_scenario_config(sc_id)
        tiers = ["EASY", "MEDIUM", "HARD"]

        for diff in tiers:
            successes = 0
            collisions = 0
            timeouts = 0
            times = []

            for seed in range(42, 62):
                self.benchmark_queue.put({
                    'type': 'progress',
                    'text': "Evaluating {}: Seed {} / 61...".format(diff, seed)
                })

                np.random.seed(seed)
                env = CustomNavRepEncodedEnv(
                    scenario=sc_id,
                    difficulty=diff,
                    gpu=False,
                    silent=True
                )
                env.reset(sc_id, diff)
                sync_and_rasterize_sim(env.raw_env, cfg)

                if sc_id == "hotelroomservice":
                    ctrl = HotelNavigationController()
                else:
                    ctrl = LibraryNavigationController()
                ctrl.reset()

                t_limit = 380
                ep_done = False
                ep_steps = 0
                ep_event = None

                for s_idx in range(t_limit):
                    r_pos = [env.soadrl_sim.robot.px, env.soadrl_sim.robot.py]
                    act = ctrl.act(r_pos, env.soadrl_sim.humans, action_dim=2)
                    ob, rew, d, inf = env.step(act)
                    ep_steps += 1
                    ev = inf.get('event')

                    tg = cfg.robot_goal
                    if math.hypot(tg[0] - r_pos[0], tg[1] - r_pos[1]) < 0.35 and ctrl.current_wp_idx >= len(ctrl.waypoints) - 1:
                        d = True
                        ev = ReachGoal()

                    if d:
                        ep_done = True
                        ep_event = ev
                        break

                env.close()

                if isinstance(ep_event, ReachGoal):
                    successes += 1
                    times.append(ep_steps * 0.2)
                elif isinstance(ep_event, (Collision, CollisionOtherAgent)):
                    collisions += 1
                else:
                    timeouts += 1

            avg_t = np.mean(times) if times else 0.0
            results[diff] = {
                'success': (successes / 20.0) * 100.0,
                'success_count': successes,
                'collision': (collisions / 20.0) * 100.0,
                'timeout': (timeouts / 20.0) * 100.0,
                'avg_time': avg_t
            }

        self.benchmark_queue.put({'type': 'complete', 'results': results})

    def _process_benchmark_queue(self):
        """Checks for updates from the benchmark worker thread."""
        try:
            while not self.benchmark_queue.empty():
                msg = self.benchmark_queue.get_nowait()
                if msg['type'] == 'progress':
                    self.lbl_bench_progress.configure(text=msg['text'])
                elif msg['type'] == 'complete':
                    res = msg['results']
                    self.lbl_bench_easy.configure(
                        text="EASY   : {:5.1f}% ({:2d}/20) | {:2.0f}%| {:2.0f}% | {:4.1f}s".format(
                            res['EASY']['success'], res['EASY']['success_count'],
                            res['EASY']['collision'], res['EASY']['timeout'], res['EASY']['avg_time'])
                    )
                    self.lbl_bench_med.configure(
                        text="MEDIUM : {:5.1f}% ({:2d}/20) | {:2.0f}%| {:2.0f}% | {:4.1f}s".format(
                            res['MEDIUM']['success'], res['MEDIUM']['success_count'],
                            res['MEDIUM']['collision'], res['MEDIUM']['timeout'], res['MEDIUM']['avg_time'])
                    )
                    self.lbl_bench_hard.configure(
                        text="HARD   : {:5.1f}% ({:2d}/20) | {:2.0f}%| {:2.0f}% | {:4.1f}s".format(
                            res['HARD']['success'], res['HARD']['success_count'],
                            res['HARD']['collision'], res['HARD']['timeout'], res['HARD']['avg_time'])
                    )
                    self.lbl_bench_progress.configure(text="Benchmark Complete! (60/60 episodes evaluated)")
                    self.btn_benchmark.configure(state="normal", text="Run 20-Seed Benchmark")
                    self.is_benchmark_running = False
        except Exception:
            pass

        self.root.after(100, self._process_benchmark_queue)


def main():
    parser = argparse.ArgumentParser(description="NavRep Interactive Demonstration GUI")
    parser.add_argument("--scenario", choices=["library", "hotelroomservice", "hotel"], default="library",
                        help="Scenario to load initially ('library' or 'hotelroomservice')")
    args, unknown = parser.parse_known_args()
    sc = "hotelroomservice" if args.scenario in ["hotel", "hotelroomservice"] else "library"

    root = tk.Tk()
    app = LibraryDemoApp(root, default_scenario=sc)
    root.mainloop()


if __name__ == "__main__":
    main()
'''

with open('/Users/shriyasiddesh/cs/air-lab/AI_Robotics/submission/task3_custom/gui/library_gui.py', 'w') as f:
    f.write(content)

with open('/Users/shriyasiddesh/cs/air-lab/AI_Robotics/navrep_custom/library_gui.py', 'w') as f:
    f.write(content)

print("Unified library_gui.py written to both submission and navrep_custom directories.")
